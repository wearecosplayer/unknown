'use strict';
const $ = s => document.querySelector(s);
const esc = v => String(v ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const today = () => new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Makassar',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());
const displayDate = s => s ? new Intl.DateTimeFormat('id-ID',{day:'numeric',month:'short',year:'numeric',timeZone:'Asia/Makassar'}).format(new Date(s.length===10?s+'T00:00:00+08:00':s)) : '—';
const icons = {
 dashboard:'<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
 students:'<circle cx="9" cy="8" r="3"/><path d="M3 21v-3a6 6 0 0 1 12 0v3M16 5a3 3 0 0 1 0 6M18 15a5 5 0 0 1 3 5"/>',
 recitations:'<path d="M4 3h7a3 3 0 0 1 3 3v15a5 5 0 0 0-4-2H4V3Zm16 0h-3a3 3 0 0 0-3 3v15a5 5 0 0 1 4-2h2V3Z"/>',
 targets:'<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/>',
 report:'<path d="M5 3h10l4 4v14H5V3Zm9 0v5h5M8 12h8M8 16h6"/>',
 achievements:'<path d="M8 3h8v7a4 4 0 0 1-8 0V3ZM8 5H4v3a4 4 0 0 0 4 4m8-7h4v3a4 4 0 0 1-4 4m-4 2v6m-4 1h8"/>',
 classes:'<path d="m3 10 9-7 9 7M5 9v12h14V9M9 21v-7h6v7M11 8h2"/>',
 attendance:'<rect x="4" y="5" width="16" height="16" rx="2"/><path d="M8 3v4m8-4v4M4 10h16m-12 5 3 3 5-5"/>',
 settings:'<path d="M4 7h16M4 17h16"/><circle cx="9" cy="7" r="3"/><circle cx="15" cy="17" r="3"/>',
 profiles:'<circle cx="12" cy="8" r="4"/><path d="M4 21v-2a8 8 0 0 1 16 0v2"/>',
 audit_logs:'<path d="M5 4h14v17H5zM9 4V2h6v2M8 9h8M8 13h8M8 17h5"/>',
 assignments:'<path d="M3 5h7v7H3zm11 7h7v7h-7zM10 8h7v4M7 12v5h7"/>'
};
const icon = name => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden="true">${icons[name]||icons.recitations}</svg>`;
const labels={dashboard:'Dashboard',students:'Data Siswa',classes:'Data Kelas',recitations:'Setoran Hafalan',attendance:'Kehadiran',targets:'Target Hafalan',achievements:'Prestasi Siswa',report:'Laporan & Cetak',profiles:'Akun Pengguna',assignments:'Kelas Binaan',audit_logs:'Log Aktivitas',settings:'Profil Sekolah'};
const roleLabel={admin:'Administrator',teacher:'Guru pembimbing',student:'Siswa'};
let state={demo:location.pathname==='/demo',user:null,csrf:'',lookups:{students:[],classes:[],surahs:[],teachers:[]},route:'dashboard',offset:0,filter:'',search:'',month:today().slice(0,7),rows:[],epoch:0};
let toastTimer, editing=null;
function toast(message){$('#toast').textContent=message;$('#toast').hidden=false;clearTimeout(toastTimer);toastTimer=setTimeout(()=>$('#toast').hidden=true,4500);}
function showError(element,message){element.textContent=message;element.hidden=!message;}
async function api(path,method='GET',data){
 if(state.demo)return demoApi(path,method,data);
 const r=await fetch('/api/'+path,{method,credentials:'same-origin',headers:{'Content-Type':'application/json',...(method!=='GET'?{'X-CSRF-Token':state.csrf}:{})},...(data?{body:JSON.stringify(data)}:{})});
 const result=await r.json();
 if(!r.ok){if(r.status===401 && state.user){state.user=null;$('#app').hidden=true;$('#login').hidden=false;showError($('#login-error'),'Sesi berakhir. Muat ulang halaman dan masuk kembali.');}throw new Error(result.error||'Permintaan tidak berhasil.');}
 return result;
}
function availableRoutes(){return state.user.role==='admin'?Object.keys(labels):state.user.role==='teacher'?['dashboard','students','recitations','attendance','targets','achievements','report','settings']:['dashboard','recitations','attendance','targets','achievements','report','settings'];}
async function enterApp(){
 $('#login').hidden=true;$('#app').hidden=false;$('#demo-banner').hidden=!state.demo;
 $('#user-name').textContent=state.user.name;$('#user-role').textContent=roleLabel[state.user.role];$('#avatar').textContent=state.user.name.split(' ').slice(0,2).map(x=>x[0]).join('');
 $('#navigation').innerHTML=availableRoutes().map(key=>`<a href="#${key}" data-nav="${key}">${icon(key)}${labels[key]}</a>`).join('');
 try{state.lookups=await api('lookups');await renderRoute();}catch(e){$('#page').innerHTML=`<div class="error-panel">${esc(e.message)} <button class="secondary" id="retry-load">Coba lagi</button></div>`;$('#retry-load').onclick=enterApp;}
}
function heading(title,description,action=''){return `<div class="page-heading"><div><span class="eyebrow">SMP MUHAMMADIYAH 4 BANJARMASIN</span><h1>${esc(title)}</h1><p>${esc(description)}</p></div>${action?`<div class="heading-tools">${action}</div>`:''}</div>`;}
function person(id){return state.lookups.students.find(s=>s.id===id)||{name:'Siswa tidak tersedia',nisn:'',class_id:''};}
function className(id){return state.lookups.classes.find(c=>c.id===id)?.name||'—';}
function surahName(id){return state.lookups.surahs.find(s=>String(s.id)===String(id))?.name||'—';}
function badge(value){return `<span class="badge ${['Perlu pengulangan','Alpa'].includes(value)?'warn':value==='Izin'||value==='Sakit'?'neutral':''}">${esc(value)}</span>`;}
function personCell(id){const p=person(id);return `<strong>${esc(p.name)}</strong><small>${esc(p.nisn)} · ${esc(className(p.class_id))}</small>`;}
function empty(message='Belum ada data untuk pilihan ini.'){return `<div class="empty"><strong>Belum ada catatan</strong>${esc(message)}</div>`;}
async function renderRoute(){
 const route=location.hash.slice(1)||'dashboard';state.route=availableRoutes().includes(route)?route:'dashboard';
 $('#breadcrumb').innerHTML=`Ruang monitoring <span>/ ${labels[state.route]}</span>`;
 document.querySelectorAll('[data-nav]').forEach(a=>a.classList.toggle('active',a.dataset.nav===state.route));
 $('#sidebar').classList.remove('open');$('#menu-toggle').setAttribute('aria-expanded','false');
 const epoch=++state.epoch;$('#page').innerHTML='<div class="loading" role="status">Memuat catatan pembelajaran…</div>';
 try{
   if(state.route==='dashboard')await dashboard(epoch);
   else if(state.route==='report')reportPage();
   else if(state.route==='settings')settingsPage();
   else await tablePage(epoch);
 }catch(e){if(epoch===state.epoch)$('#page').innerHTML=`<div class="error-panel" role="alert">${esc(e.message)}</div>`;}
}
async function dashboard(epoch){
 const [d,recent]=await Promise.all([api('dashboard?month='+state.month),api('recitations')]);if(epoch!==state.epoch)return;
 const progress=(d.progress||[]).filter(x=>x.goal).slice(0,4);const daily=new Map((d.daily||[]).map(x=>[x.day,Number(x.total)]));
 const days=new Date(Number(state.month.slice(0,4)),Number(state.month.slice(5,7)),0).getDate();const max=Math.max(1,...daily.values());
 $('#page').innerHTML=heading('Dashboard','Pantau perjalanan hafalan, dampingi setiap kemajuan.',`<input aria-label="Bulan monitoring" type="month" id="dashboard-month" value="${esc(state.month)}">${state.user.role!=='student'?'<button class="primary" id="quick-add">＋ Setoran baru</button>':''}`)+
 `<section class="welcome"><div><span class="eyebrow">RUANG TUMBUH GENERASI QURANI</span><h2>Assalamu’alaikum, ${esc(state.user.name.split(' ')[0])}.</h2><p>Setiap ayat adalah langkah kebaikan. Mari jaga semangat belajar<br>dan rayakan kemajuan hafalan hari ini.</p></div><div class="welcome-end">✧</div></section>`+
 `<section class="stats" aria-label="Ringkasan bulan terpilih">${[['Siswa aktif',d.students,'students','Sesuai hak akses akun'],['Setoran bulan ini',d.sessions,'recitations','Hafalan baru & murajaah'],['Rata-rata nilai',d.average??'—','achievements','Skala penilaian 0–100'],['Perlu pengulangan',d.review,'targets','Catatan untuk pendampingan']].map(([label,val,i,note])=>`<article class="stat"><div class="stat-top">${label}<span class="stat-icon">${icon(i)}</span></div><strong>${esc(val)}</strong><small>${note}</small></article>`).join('')}</section>`+
 `<section class="dashboard-grid"><div class="panel"><div class="panel-heading"><div><h2>Aktivitas setoran</h2><p>Jumlah setoran per hari · ${esc(state.month)}</p></div><span class="badge">Bulan ini</span></div><div class="panel-body"><div class="chart" role="img" aria-label="${esc((d.daily||[]).map(x=>x.day+': '+x.total+' setoran').join('; ')||'Belum ada setoran')}">${Array.from({length:days},(_,i)=>{const n=daily.get(state.month+'-'+String(i+1).padStart(2,'0'))||0;return `<div class="bar-slot" title="${i+1}: ${n} setoran"><div class="bar" data-height="${Math.max(1,n/max*100)}"></div>${i===0||(i+1)%5===0?`<span>${i+1}</span>`:''}</div>`;}).join('')}</div><div class="chart-note">● Setoran yang tersimpan pada bulan terpilih</div></div></div>
 <div class="panel"><div class="panel-heading"><div><h2>Kemajuan target</h2><p>Target jumlah setoran per bulan</p></div><a href="#targets">Lihat semua →</a></div><div class="panel-body">${progress.length?progress.map(p=>`<div class="target-row"><span class="initial">${esc(p.name[0])}</span><div class="target-info"><strong>${esc(p.name)}</strong><small>${esc(className(p.class_id))} · ${p.sessions} / ${p.goal} setoran</small><progress max="${Number(p.goal)}" value="${Number(p.sessions)}">${p.sessions}/${p.goal}</progress></div><span class="target-pct">${Math.round(p.sessions/p.goal*100)}%</span></div>`).join(''):empty('Atur target bulanan untuk melihat kemajuan.')}</div></div></section>`+
 `<section class="panel"><div class="panel-heading"><div><h2>Setoran terbaru</h2><p>Catatan terakhir dari seluruh periode</p></div><a href="#recitations">Semua setoran →</a></div>${recent.rows.length?recitationTable(recent.rows.slice(0,5),false):empty('Mulai dengan mencatat setoran pertama.')}</section>`;
 document.querySelectorAll('.bar[data-height]').forEach(el=>el.style.height=el.dataset.height+'%');
 $('#dashboard-month').onchange=e=>{if(/^\d{4}-\d{2}$/.test(e.target.value)){state.month=e.target.value;renderRoute();}};
 if($('#quick-add'))$('#quick-add').onclick=()=>openEditor('recitations');
}
const fields={
 classes:[['name','Nama kelas','text',true],['academic_year','Tahun ajaran (2026/2027)','text',true]],
 students:[['nisn','NISN','text',true],['name','Nama siswa','text',true],['class_id','Kelas','classes',true],['gender','Jenis kelamin','gender',true]],
 assignments:[['teacher_id','Guru pembimbing','teachers',true],['class_id','Kelas binaan','classes',true]],
 recitations:[['student_id','Siswa','students',true],['recorded_on','Tanggal setoran','date',true],['surah_id','Surah','surahs',true],['kind','Jenis setoran','kind',true],['verse_from','Ayat awal','number',true],['verse_to','Ayat akhir','number',true],['score','Nilai (0–100)','number',true],['quality','Hasil penilaian','quality',true],['notes','Catatan pembimbing','textarea',false]],
 attendance:[['student_id','Siswa','students',true],['attended_on','Tanggal','date',true],['status','Kehadiran','status',true],['notes','Catatan','textarea',false]],
 targets:[['student_id','Siswa','students',true],['month','Bulan target','month',true],['sessions_goal','Target jumlah setoran','number',true],['description','Catatan target','textarea',false]],
 achievements:[['student_id','Siswa','students',true],['achieved_on','Tanggal prestasi','date',true],['title','Nama prestasi','text',true],['description','Keterangan','textarea',false]]
};
function options(type){
 if(type==='students')return state.lookups.students.filter(x=>x.active).map(x=>[x.id,x.name+' · '+className(x.class_id)]);
 if(type==='classes')return state.lookups.classes.map(x=>[x.id,x.name+' · '+x.academic_year]);
 if(type==='surahs')return state.lookups.surahs.map(x=>[x.id,x.id+'. '+x.name+' ('+x.verses+' ayat)']);
 if(type==='teachers')return state.lookups.teachers.map(x=>[x.id,x.name]);
 return ({gender:[['L','Laki-laki'],['P','Perempuan']],kind:[['Hafalan baru','Hafalan baru'],['Murajaah','Murajaah']],quality:[['Lancar','Lancar'],['Perlu pengulangan','Perlu pengulangan']],status:['Hadir','Izin','Sakit','Alpa'].map(x=>[x,x])})[type]||[];
}
function canWrite(r){return state.user.role==='admin'||(state.user.role==='teacher'&&['recitations','attendance','targets','achievements'].includes(r));}
function actions(row,r){
 if(!canWrite(r))return '';
 const own=state.user.role==='admin'||row.teacher_id===state.user.id||row.created_by===state.user.id;
 if(!own)return '<span class="muted">Guru lain</span>';
 let out=`<button class="tiny" data-edit="${esc(row.id)}">Edit</button>`;
 if(state.user.role==='admin')out+=r==='students'?`<button class="tiny" data-active="${esc(row.id)}">${row.active?'Nonaktifkan':'Aktifkan'}</button>`:`<button class="tiny danger" data-delete="${esc(row.id)}">Hapus</button>`;
 return out;
}
function recitationTable(rows,withActions=true){return table(['Tanggal','Siswa','Hafalan','Jenis','Nilai','Hasil',...(withActions&&canWrite('recitations')?['Aksi']:[])],rows.map(r=>[esc(displayDate(r.recorded_on)),personCell(r.student_id),`<strong>${esc(surahName(r.surah_id))}</strong><small>Ayat ${r.verse_from}–${r.verse_to}</small>`,esc(r.kind),`<span class="score">${r.score}</span>`,`${badge(r.quality)}${r.notes?`<small>${esc(r.notes)}</small>`:''}`,...(withActions&&canWrite('recitations')?[actions(r,'recitations')]:[])]));}
function table(headers,rows){return `<div class="table-wrap"><table><thead><tr>${headers.map(x=>`<th scope="col">${esc(x)}</th>`).join('')}</tr></thead><tbody>${rows.map(row=>`<tr>${row.map(c=>`<td>${c}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`;}
function rowsTable(resource,rows){
 if(!rows.length)return empty();if(resource==='recitations')return recitationTable(rows);
 let headers=[],cells=[];
 for(const r of rows){let c=[];
  if(resource==='students'){headers=['Nama siswa','NISN','Kelas','L/P','Status'];c=[`<strong>${esc(r.name)}</strong>`,esc(r.nisn),esc(className(r.class_id)),esc(r.gender),badge(r.active?'Aktif':'Nonaktif')];}
  if(resource==='classes'){headers=['Kelas','Tahun ajaran'];c=[`<strong>${esc(r.name)}</strong>`,esc(r.academic_year)];}
  if(resource==='assignments'){headers=['Guru','Kelas binaan'];c=[esc(state.lookups.teachers.find(t=>t.id===r.teacher_id)?.name||r.teacher_id),esc(className(r.class_id))];}
  if(resource==='targets'){headers=['Siswa','Bulan','Target setoran','Catatan'];c=[personCell(r.student_id),esc(r.month.slice(0,7)),esc(r.sessions_goal),esc(r.description)];}
  if(resource==='attendance'){headers=['Tanggal','Siswa','Status','Catatan'];c=[esc(displayDate(r.attended_on)),personCell(r.student_id),badge(r.status),esc(r.notes)];}
  if(resource==='achievements'){headers=['Tanggal','Siswa','Prestasi','Keterangan'];c=[esc(displayDate(r.achieved_on)),personCell(r.student_id),`<strong>${esc(r.title)}</strong>`,esc(r.description)];}
  if(resource==='profiles'){headers=['Nama','NIP / NISN','Peran','Status','Aksi'];c=[esc(r.name),esc(r.identifier),esc(roleLabel[r.role]),badge(r.active?'Aktif':'Nonaktif'),r.id===state.user.id?'Akun Anda':`<button class="tiny" data-active="${esc(r.id)}">${r.active?'Nonaktifkan':'Aktifkan'}</button>`];}
  if(resource==='audit_logs'){headers=['Waktu (WITA)','Tindakan','Tabel','ID data','ID pelaku'];c=[esc(new Date(r.created_at).toLocaleString('id-ID',{timeZone:'Asia/Makassar'})),esc(r.action),esc(r.entity),esc(r.entity_id),esc(r.actor_id||'Provisioning / sistem')];}
  if(canWrite(resource)){c.push(actions(r,resource));}cells.push(c);
 }
 if(canWrite(resource))headers.push('Aksi');return table(headers,cells);
}
async function tablePage(epoch){
 const r=state.route;let query=new URLSearchParams({offset:state.offset});
 if(state.filter)query.set(r==='students'?'class_id':'student_id',state.filter);
 if(state.search)query.set('search',state.search);
 const result=await api(r+'?'+query);if(epoch!==state.epoch)return;state.rows=result.rows;
 const hasStudentFilter=['recitations','attendance','targets','achievements'].includes(r);const searchable=['students','profiles'].includes(r);
 const filterOptions=r==='students'?options('classes'):state.lookups.students.map(s=>[s.id,s.name]);
 $('#page').innerHTML=heading(labels[r],{recitations:'Catat hafalan baru, murajaah, dan hasil penilaian.',students:'Data siswa yang dapat diakses oleh akun Anda.',targets:'Tetapkan target jumlah setoran setiap bulan.',attendance:'Pantau kehadiran kegiatan tahfizh.',profiles:'Kelola status akun. Pembuatan akun dilakukan melalui alat provisioning.',audit_logs:'Riwayat perubahan data. Hanya administrator yang dapat melihatnya.',assignments:'Tentukan kelas yang boleh dikelola setiap guru.'}[r]||'Kelola catatan dan dukung perkembangan siswa.',canWrite(r)?'<button class="primary" id="add-row">＋ Tambah data</button>':'')+
 (r==='profiles'?'<div class="info-card"><b>Penambahan akun</b><p>Pengelola menjalankan <code>php bin/provision.php</code> melalui terminal lokal untuk membuat akun guru, admin, atau siswa. Tidak ada akun atau password bawaan.</p></div><br>':'')+
 `<div class="toolbar">${searchable?`<input id="search" placeholder="Cari berdasarkan nama…" aria-label="Cari nama" value="${esc(state.search)}"><button id="search-button" class="secondary">Cari</button>`:''}${hasStudentFilter||r==='students'?`<select id="table-filter" aria-label="Filter ${r==='students'?'kelas':'siswa'}"><option value="">Semua ${r==='students'?'kelas':'siswa'}</option>${filterOptions.map(([id,name])=>`<option value="${esc(id)}" ${state.filter===id?'selected':''}>${esc(name)}</option>`).join('')}</select>`:''}<button id="reload" class="secondary">↻ Muat ulang</button></div>`+
 `<section class="panel">${rowsTable(r,result.rows)}<div class="pagination"><span>Halaman ${state.offset/50+1}</span><button class="tiny" id="prev" ${state.offset===0?'disabled':''}>← Sebelumnya</button><button class="tiny" id="next" ${!result.has_more?'disabled':''}>Berikutnya →</button></div></section>`;
 if($('#add-row'))$('#add-row').onclick=()=>openEditor(r);
 if($('#table-filter'))$('#table-filter').onchange=e=>{state.filter=e.target.value;state.offset=0;renderRoute();};
 if($('#search-button')){$('#search-button').onclick=()=>{state.search=$('#search').value.trim();state.offset=0;renderRoute();};$('#search').onkeydown=e=>{if(e.key==='Enter')$('#search-button').click();};}
 $('#reload').onclick=()=>renderRoute();$('#prev').onclick=()=>{state.offset=Math.max(0,state.offset-50);renderRoute();};$('#next').onclick=()=>{state.offset+=50;renderRoute();};
 $('#page').querySelectorAll('[data-edit]').forEach(b=>b.onclick=()=>openEditor(r,state.rows.find(x=>x.id===b.dataset.edit)));
 $('#page').querySelectorAll('[data-delete]').forEach(b=>b.onclick=async()=>{if(!confirm('Hapus catatan ini? Penghapusan tidak dapat dibatalkan dari aplikasi.'))return;await mutateButton(b,()=>api(r+'/'+b.dataset.delete,'DELETE'));});
 $('#page').querySelectorAll('[data-active]').forEach(b=>b.onclick=async()=>{const row=state.rows.find(x=>x.id===b.dataset.active);if(!confirm(`${row.active?'Nonaktifkan':'Aktifkan'} ${row.name}?`))return;await mutateButton(b,()=>api(r+'/'+row.id,'PATCH',{active:!row.active}));});
}
async function mutateButton(button,fn){button.disabled=true;try{await fn();state.lookups=await api('lookups');toast('Perubahan berhasil disimpan.');await renderRoute();}catch(e){toast(e.message);button.disabled=false;}}
function openEditor(resource,row=null){
 editing={resource,row};$('#modal-title').textContent=(row?'Edit ':'Tambah ')+labels[resource];showError($('#form-error'),'');
 $('#fields').innerHTML=fields[resource].map(([key,label,type,required])=>{
  let value=row?.[key]??(type==='date'?today():type==='month'?state.month:key==='academic_year'?'2026/2027':'');if(type==='month')value=String(value).slice(0,7);
  const attrs=`id="field-${key}" name="${key}" ${required?'required':''}`;let control;
  if(type==='textarea')control=`<textarea ${attrs} maxlength="${key==='description'&&resource==='targets'?300:1000}">${esc(value)}</textarea>`;
  else if(['text','date','month','number'].includes(type))control=`<input ${attrs} type="${type}" value="${esc(value)}" ${type==='date'?`max="${today()}"`:''} ${type==='number'?`min="${key==='score'?0:1}" max="${key==='score'||key==='sessions_goal'?100:286}" step="1"`:''} ${type==='text'?`maxlength="${key==='nisn'?25:key==='name'?100:key==='title'?150:40}"`:''}>`;
  else control=`<select ${attrs}><option value="">Pilih ${esc(label.toLowerCase())}</option>${options(type).map(([id,text])=>`<option value="${esc(id)}" ${String(id)===String(value)?'selected':''}>${esc(text)}</option>`).join('')}</select>`;
  return `<div class="field ${['textarea'].includes(type)||key==='student_id'?'full':''}"><label for="field-${key}">${label}${required?' *':''}</label>${control}</div>`;
 }).join('');
 if(resource==='recitations'){$('#field-surah_id').onchange=()=>{const s=state.lookups.surahs.find(x=>String(x.id)===$('#field-surah_id').value);for(const id of ['verse_from','verse_to'])$('#field-'+id).max=s?.verses||286;};$('#field-surah_id').onchange();}
 $('#editor').showModal();
}
$('#editor-form').onsubmit=async e=>{
 e.preventDefault();const submit=e.submitter;submit.disabled=true;showError($('#form-error'),'');
 try{const b=Object.fromEntries(new FormData(e.target));for(const key of ['surah_id','verse_from','verse_to','score','sessions_goal'])if(key in b)b[key]=Number(b[key]);
 if('verse_from'in b&&b.verse_to<b.verse_from)throw new Error('Ayat akhir tidak boleh lebih kecil dari ayat awal.');
 await api(editing.resource+(editing.row?'/'+editing.row.id:''),editing.row?'PATCH':'POST',b);
 $('#editor').close();state.lookups=await api('lookups');toast('Data berhasil disimpan.');await renderRoute();
 }catch(err){showError($('#form-error'),err.message);}finally{submit.disabled=false;}
};
$('#close-modal').onclick=$('#cancel-modal').onclick=()=>$('#editor').close();
function reportPage(){
 $('#page').innerHTML=heading('Laporan & Cetak','Rekap setoran sesuai periode dan hak akses Anda.')+`<div class="toolbar"><label>Dari <input type="date" id="report-from" value="${state.month}-01"></label><label>Sampai <input type="date" id="report-to" value="${today()}"></label><select id="report-student" aria-label="Siswa laporan"><option value="">Semua siswa</option>${state.lookups.students.map(s=>`<option value="${esc(s.id)}">${esc(s.name)}</option>`).join('')}</select><button class="primary" id="make-report">Tampilkan</button><button class="secondary" id="export-csv" disabled>Unduh CSV</button><button class="secondary" id="print-report" disabled>Cetak / PDF</button></div><div id="report-content" class="panel">${empty('Pilih periode lalu tekan Tampilkan.')}</div>`;
 let report=null,query='';
 const invalidate=()=>{$('#export-csv').disabled=true;$('#print-report').disabled=true;};
 ['report-from','report-to','report-student'].forEach(id=>$('#'+id).onchange=invalidate);
 $('#make-report').onclick=async()=>{const btn=$('#make-report');btn.disabled=true;invalidate();try{
 query=new URLSearchParams({from:$('#report-from').value,to:$('#report-to').value,student_id:$('#report-student').value}).toString();
 report=await api('report?'+query);
 $('#report-content').innerHTML=`<div class="panel-heading"><div><h2>Laporan Setoran Hafalan</h2><p>SMP Muhammadiyah 4 Banjarmasin · ${esc(displayDate(report.from))}–${esc(displayDate(report.to))} · ${report.rows.length} catatan</p></div></div>${report.rows.length?table(['Tanggal','NISN','Nama','Kelas','Surah / Ayat','Jenis','Nilai','Hasil','Catatan'],report.rows.map(r=>[esc(displayDate(r.recorded_on)),esc(r.nisn),esc(r.student_name),esc(r.class_name),`${esc(r.surah_name)} ${r.verse_from}–${r.verse_to}`,esc(r.kind),esc(r.score),esc(r.quality),esc(r.notes)])):empty()}`;
 $('#export-csv').disabled=false;$('#print-report').disabled=false;
 }catch(e){toast(e.message);}finally{btn.disabled=false;}};
 $('#print-report').onclick=()=>window.print();
 $('#export-csv').onclick=async()=>{if(!report)return;try{
 let blob;
 if(state.demo){const safe=v=>{let s=String(v??'');if(/^\s*[=+@\-\t\r\n]/.test(s))s="'"+s;return '"'+s.replaceAll('"','""')+'"';};blob=new Blob(['\uFEFF'+[['Tanggal','NISN','Nama','Kelas','Surah','Ayat awal','Ayat akhir','Nilai','Hasil'],...report.rows.map(r=>[r.recorded_on,r.nisn,r.student_name,r.class_name,r.surah_name,r.verse_from,r.verse_to,r.score,r.quality])].map(row=>row.map(safe).join(',')).join('\r\n')],{type:'text/csv;charset=utf-8'});}
 else{const res=await fetch('/api/report?'+query+'&format=csv',{credentials:'same-origin'});if(!res.ok)throw new Error('Ekspor gagal. Periksa sesi login.');blob=await res.blob();}
 const link=document.createElement('a');link.href=URL.createObjectURL(blob);link.download='laporan-hafalan'+(state.demo?'-DEMO':'')+'.csv';link.click();setTimeout(()=>URL.revokeObjectURL(link.href),1000);
 }catch(e){toast(e.message);}};
}
function settingsPage(){
 $('#page').innerHTML=heading('Profil Sekolah','Identitas sekolah dan informasi penggunaan aplikasi.')+`<div class="info-grid"><section class="info-card"><span class="eyebrow">IDENTITAS SEKOLAH</span><h2>SMP Muhammadiyah 4 Banjarmasin</h2><p>NPSN <b>30304181</b><br>Jl. Pekapuran Raya RW. 1 RT. 9<br>Pekapuran Raya, Banjarmasin Timur<br>Kota Banjarmasin, Kalimantan Selatan</p><p>Sumber: <a href="https://referensi.data.kemendikdasmen.go.id/pendidikan/npsn/30304181" target="_blank" rel="noopener noreferrer">Data Pendidikan Kemendikdasmen</a><br>Diakses 25 Oktober 2026.</p></section><section class="info-card"><span class="eyebrow">AKUN & AKSES</span><h2>${esc(state.user.name)}</h2><p>Peran: ${esc(roleLabel[state.user.role])}<br>ID: ${esc(state.user.identifier)}<br>Zona waktu: WITA (Asia/Makassar)</p><p>Sesi berakhir setelah maksimal 30 menit. Untuk perubahan password atau akun, hubungi administrator sekolah. Target dihitung berdasarkan jumlah setoran, bukan jumlah ayat unik yang telah dikuasai.</p></section></div>`;
}
$('#login-form').onsubmit=async e=>{
 e.preventDefault();const button=e.submitter;button.disabled=true;showError($('#login-error'),'');
 try{const fresh=await api('session');state.csrf=fresh.csrf;const r=await api('login','POST',{identifier:$('#identifier').value,password:$('#password').value});$('#password').value='';state.csrf=r.csrf;state.user=r.user;await enterApp();}catch(err){showError($('#login-error'),err.message);}finally{button.disabled=false;}
};
$('#show-password').onclick=()=>{const visible=$('#password').type==='password';$('#password').type=visible?'text':'password';$('#show-password').setAttribute('aria-label',visible?'Sembunyikan password':'Tampilkan password');};
$('#logout').onclick=async()=>{try{if(!state.demo)await api('logout','POST',{});location.href='/';}catch(e){toast(e.message);}};
$('#menu-toggle').onclick=()=>{const open=$('#sidebar').classList.toggle('open');$('#menu-toggle').setAttribute('aria-expanded',String(open));};
window.addEventListener('hashchange',()=>{state.offset=0;state.filter='';state.search='';if(state.user)renderRoute();});

// Demo terpisah: tidak menggunakan akun nyata, tidak mengirim data ke Supabase.
const fakeId=i=>'00000000-0000-4000-8000-'+String(i).padStart(12,'0');
const demoId=()=>Array.from(crypto.getRandomValues(new Uint8Array(16)),(v,i)=>([4,6,8,10].includes(i)?'-':'')+v.toString(16).padStart(2,'0')).join('');
const demo={classes:[{id:fakeId(1),name:'VII A',academic_year:'2026/2027'},{id:fakeId(2),name:'VIII A',academic_year:'2026/2027'},{id:fakeId(3),name:'IX A',academic_year:'2026/2027'}],students:[],recitations:[],attendance:[],targets:[],achievements:[],assignments:[],profiles:[],audit_logs:[],surahs:[{id:78,name:'An-Naba',verses:40},{id:87,name:'Al-Ala',verses:19},{id:112,name:'Al-Ikhlas',verses:4},{id:113,name:'Al-Falaq',verses:5},{id:114,name:'An-Nas',verses:6}]};
function initDemo(){
 state.user={id:fakeId(90),name:'Guru Demo',identifier:'999999999',role:'admin',active:true};demo.profiles=[state.user,{id:fakeId(91),name:'Pembimbing Demo',identifier:'999999998',role:'teacher',active:true}];
 const names=['Siswa Contoh A','Siswa Contoh B','Siswa Contoh C','Siswa Contoh D','Siswa Contoh E','Siswa Contoh F','Siswa Contoh G','Siswa Contoh H'];
 names.forEach((name,i)=>{demo.students.push({id:fakeId(100+i),name,nisn:'99999000'+i,class_id:fakeId(i%3+1),gender:i%2?'P':'L',active:true});demo.targets.push({id:fakeId(200+i),student_id:fakeId(100+i),month:state.month+'-01',sessions_goal:8,description:'Target demonstrasi',created_by:state.user.id,created_at:new Date().toISOString()});});
 for(let i=0;i<42;i++){const s=demo.students[i%8],surah=demo.surahs[i%5];demo.recitations.push({id:fakeId(300+i),student_id:s.id,teacher_id:state.user.id,recorded_on:state.month+'-'+String(1+i%Math.min(Number(today().slice(-2)),28)).padStart(2,'0'),surah_id:surah.id,verse_from:1,verse_to:surah.verses,score:75+i%26,kind:i%3?'Hafalan baru':'Murajaah',quality:i%7?'Lancar':'Perlu pengulangan',notes:i%7?'':'Ulangi dengan tempo lebih perlahan.',created_at:new Date(Date.now()-i*60000).toISOString()});}
 demo.achievements=[{id:fakeId(500),student_id:fakeId(100),title:'Konsisten murajaah — contoh',achieved_on:today(),description:'Data demonstrasi, bukan prestasi nyata.',created_by:state.user.id,created_at:new Date().toISOString()}];
 demo.assignments=[{id:fakeId(600),teacher_id:fakeId(91),class_id:fakeId(1)}];
 demo.attendance=demo.students.map((s,i)=>({id:fakeId(700+i),student_id:s.id,attended_on:today(),status:i===7?'Izin':'Hadir',notes:'Data contoh',teacher_id:state.user.id,created_at:new Date().toISOString()}));
}
async function demoApi(path,method='GET',body={}){
 const url=new URL('https://demo.invalid/'+path),[r,id]=url.pathname.slice(1).split('/');const q=url.searchParams;
 if(r==='lookups')return {classes:demo.classes,students:demo.students,surahs:demo.surahs,teachers:demo.profiles.filter(p=>p.role==='teacher')};
 if(r==='dashboard'){
 const records=demo.recitations.filter(x=>x.recorded_on.startsWith(q.get('month')));let daily={};records.forEach(x=>daily[x.recorded_on]=(daily[x.recorded_on]||0)+1);
 return {students:demo.students.filter(s=>s.active).length,sessions:records.length,average:records.length?Math.round(records.reduce((a,r)=>a+r.score,0)/records.length*10)/10:null,review:records.filter(r=>r.quality==='Perlu pengulangan').length,progress:demo.students.filter(s=>s.active).map(s=>({...s,sessions:records.filter(r=>r.student_id===s.id).length,goal:demo.targets.find(t=>t.student_id===s.id&&t.month.startsWith(q.get('month')))?.sessions_goal})),daily:Object.entries(daily).map(([day,total])=>({day,total}))};
 }
 if(r==='report'){const from=q.get('from'),to=q.get('to');if(!from||!to||from>to)throw new Error('Periode tidak valid.');return {from,to,rows:demo.recitations.filter(r=>r.recorded_on>=from&&r.recorded_on<=to&&(!q.get('student_id')||r.student_id===q.get('student_id'))).map(r=>({...r,student_name:person(r.student_id).name,nisn:person(r.student_id).nisn,class_name:className(person(r.student_id).class_id),surah_name:surahName(r.surah_id)}))};}
 if(!demo[r])throw new Error('Menu demo tidak tersedia.');
 if(method==='GET'){let rows=[...demo[r]];if(q.get('student_id'))rows=rows.filter(x=>x.student_id===q.get('student_id'));if(q.get('class_id'))rows=rows.filter(x=>x.class_id===q.get('class_id'));if(q.get('search'))rows=rows.filter(x=>x.name?.toLowerCase().includes(q.get('search').toLowerCase()));const offset=Number(q.get('offset')||0);return {rows:rows.slice(offset,offset+50),has_more:rows.length>offset+50};}
 if(method==='DELETE'){demo[r]=demo[r].filter(x=>x.id!==id);return {ok:true};}
 if(r==='targets')body.month=body.month+'-01';
 if(method==='PATCH'){const row=demo[r].find(x=>x.id===id);Object.assign(row,body);return {row};}
 const row={...body,id:demoId(),active:true,teacher_id:state.user.id,created_by:state.user.id,created_at:new Date().toISOString()};demo[r].unshift(row);return {row};
}
(async()=>{if(state.demo){initDemo();await enterApp();return;}try{const s=await api('session');state.csrf=s.csrf;state.user=s.user;if(s.user)await enterApp();}catch(e){showError($('#login-error'),e.message);}})();
