# Tahfizh Spemfour Pro

Aplikasi monitoring hafalan dan prestasi untuk **SMP Muhammadiyah 4 Banjarmasin**. Backend PHP, autentikasi Supabase Auth, database PostgreSQL Supabase, antarmuka HTML/CSS/JavaScript. Paket disiapkan untuk deployment Vercel melalui **runtime komunitas `vercel-php@0.9.0`**.

## Status penyerahan

Kode aplikasi, SQL, konfigurasi deployment, demo, dan alat pengelolaan akun tersedia. Pengujian lokal PHP, database PostgreSQL melalui PGlite, serta alur demo pada browser telah dilakukan. Proyek **belum dihubungkan ke proyek Supabase nyata dan belum dideploy ke akun Vercel pengguna**. Konfigurasi, akun awal, dan uji penerimaan pada staging tetap diperlukan.

Halaman login aplikasi Google Apps Script acuan berhasil ditinjau: nama Tahfizh Spemfour Pro, fungsi monitoring hafalan & prestasi, warna hijau, kartu login, serta isian NIP/NISN. Login otomatis ke halaman internal terhalang kompatibilitas formulir iframe dengan mekanisme autentikasi browser. **Dashboard dan susunan menu di paket ini merupakan implementasi baru, bukan salinan halaman internal yang sudah diverifikasi.** Tidak ada data siswa, password, atau kredensial sumber yang disalin.

## Fitur yang tersedia

- Login NIP/NISN melalui Supabase Auth; tidak ada akun/password bawaan.
- Dashboard bulanan: jumlah siswa aktif, jumlah setoran, rata-rata nilai, catatan pengulangan, grafik harian, dan target.
- Data kelas, siswa aktif/nonaktif, dan penugasan guru ke kelas binaan.
- Catatan hafalan baru/murajaah, 114 surah, rentang ayat, nilai, dan catatan pembimbing.
- Kehadiran, target jumlah setoran bulanan, serta catatan prestasi.
- Pencarian nama, filter siswa/kelas, pagination, edit data, dan penghapusan khusus admin.
- Laporan periode, CSV, serta cetak / simpan PDF melalui browser.
- Aktivasi/nonaktivasi akun serta audit perubahan tanpa menyalin isi catatan sensitif.
- Demo dengan data fiktif di `/demo`, terpisah dari koneksi database dan tanpa persistensi.

Target berarti **jumlah sesi/setoran**, bukan jumlah ayat unik atau sertifikasi penguasaan. Prestasi dicatat oleh guru/admin, tidak ditentukan otomatis oleh aplikasi. Pengguna siswa hanya melihat datanya sendiri.

## 1. Persiapan Supabase

Gunakan proyek Supabase **baru dan khusus untuk aplikasi ini**. SQL pertama membuat tabel dan tidak ditujukan untuk dijalankan ulang di database berisi data produksi.

1. Buka SQL Editor dan jalankan berurutan:
   - `database/001_schema.sql`
   - `database/002_surahs.sql`
   - `database/003_login_guard.sql`
2. Pastikan Data API aktif, schema `public` tersedia, dan batas Max Rows minimal **1000**. Schema `private` jangan diekspos melalui Data API.
3. Pada Authentication, aktifkan login email/password dan **nonaktifkan pendaftaran publik**. Akun dibuat oleh pengelola melalui Admin API.
4. Atur kebijakan password kuat; gunakan minimal 14 karakter unik. Atur JWT expiry **1800 detik** agar selaras dengan batas sesi aplikasi. Matikan login anonymous karena tidak diperlukan.
5. Ambil Project URL dan publishable key / anon key untuk environment aplikasi. **Service-role key tidak dimasukkan ke Vercel atau kode frontend**; hanya diperlukan alat provisioning lokal.

## 2. Buat kunci aplikasi

Memerlukan PHP 8.3+ dengan ekstensi `curl`, `mbstring`, `sodium`, dan dukungan TLS/CA certificate.

```bash
php bin/generate-keys.php
```

Perintah menghasilkan `APP_KEY`, `LOGIN_GUARD_KEY`, dan satu perintah SQL. Simpan dua kunci pada environment Vercel. Jalankan perintah SQL yang dihasilkan di SQL Editor Supabase untuk mengisi kunci verifikasi pembatas login. Jangan menyimpan output perintah tersebut ke Git atau membagikannya.

Environment yang harus diisi:

| Variabel | Nilai |
| --- | --- |
| `APP_ENV` | `production` |
| `APP_URL` | Origin HTTPS situs final, misalnya `https://nama-proyek.vercel.app`, tanpa path dan tanpa garis miring akhir |
| `APP_KEY` | Hasil generator, Base64 32 byte |
| `LOGIN_GUARD_KEY` | Hasil generator, 64 karakter hex; sama dengan nilai di tabel private |
| `SUPABASE_URL` | `https://PROJECT_REF.supabase.co` |
| `SUPABASE_ANON_KEY` | Publishable key atau anon key proyek |
| `AUTH_EMAIL_DOMAIN` | `accounts.spemfour.invalid` |

`.env.example` hanya contoh nama variabel. File `.env` tidak diunggah. `APP_URL` harus sama persis dengan origin yang dibuka pengguna; bila memakai custom domain, gunakan domain utama yang sama untuk akses aplikasi. Preview deployment menggunakan environment tersendiri.

## 3. Membuat admin dan akun lain

Instal PHP 8.3+ dan Python 3 pada komputer pengelola. Jalankan:

```bash
python3 bin/provision.py
```

Wizard meminta Supabase URL, **legacy service_role key**, ID, nama, peran, dan password secara lokal. Rahasia dikirim ke PHP melalui stdin/environment, tidak ditaruh pada argumen proses atau file. Gunakan `admin` untuk akun pertama. Jalankan ulang untuk peran `teacher` atau `student`.

ID harus 6–25 digit, disimpan sebagai teks agar nol awal tidak hilang. Supabase Auth menggunakan alamat internal `ID@accounts.spemfour.invalid`; pengguna tetap login dengan NIP/NISN. Alamat ini bukan kotak email untuk reset password.

Urutan pengisian setelah admin pertama bisa masuk:

1. Tambahkan kelas dan tahun ajaran melalui **Data Kelas**.
2. Tambahkan siswa melalui **Data Siswa**.
3. Buat akun guru lewat wizard, lalu hubungkan guru ke kelas melalui **Kelas Binaan**.
4. Bila siswa perlu login, buat akun `student` dengan ID **sama persis** dengan NISN yang sudah ada. Wizard otomatis menghubungkan profil dan siswa. NISN yang sudah terhubung akun tidak dapat diganti sembarangan.
5. Guru menetapkan target, mencatat setoran/kehadiran, dan menghasilkan laporan.

Perubahan password ditangani operator melalui Supabase Auth Admin API atau dashboard sesuai prosedur sekolah. Untuk pencabutan akses segera, nonaktifkan profil di aplikasi. Jangan membuat password umum untuk semua pengguna. Akun admin sendiri tidak dapat dinonaktifkan melalui tombol status akun.

## 4. Deployment Vercel

Vercel tidak menjalankan PHP sebagai runtime native resminya; paket menggunakan runtime komunitas yang versi konfigurasinya dikunci. Dukungan dan kompatibilitasnya perlu diverifikasi pada deployment Anda.

**ZIP perlu diekstrak terlebih dahulu**, kemudian deploy folder yang berisi `vercel.json`.

### Melalui Git

1. Ekstrak ZIP. Upload source ke repository privat milik Anda. Jangan sertakan `.env`, `.vercel`, atau `node_modules`.
2. Import repository ke Vercel. Pilih Framework Preset **Other**, Root Directory sesuai folder `spemfour`, Node.js **22.x**.
3. Kosongkan override Build Command dan Install Command; proyek tidak memerlukan build frontend atau instalasi Node untuk runtime. Jangan memilih preset Vite/Next.js. Tidak perlu mengisi Output Directory khusus.
4. Isi environment sesuai tabel. Tentukan domain stabil untuk `APP_URL`.
5. Deploy. `vercel.json` mengarahkan semua request ke `api/index.php`; hanya aset yang diizinkan yang dapat disajikan.
6. Jika domain belum diketahui saat deployment pertama, salin domain final ke `APP_URL`, lalu redeploy. Kegagalan konfigurasi menampilkan pesan yang aman; tidak membuka data.

### Melalui Vercel CLI

Dengan CLI Vercel yang sudah terpasang dan terautentikasi:

```bash
cd spemfour
vercel
# Isi environment melalui dashboard/CLI, lalu:
vercel --prod
```

Jangan mengunggah ZIP langsung sebagai berkas situs. Jangan menyajikan folder proyek menggunakan static hosting biasa karena file PHP membutuhkan runtime.

## 5. Uji lokal

Demo tidak membutuhkan Supabase:

```bash
php -S 127.0.0.1:8000 api/index.php
```

Buka `http://127.0.0.1:8000/demo`. Mode demo menyediakan lima pilihan surah contoh; database aplikasi sebenarnya memuat 114 surah.

Untuk menguji login sungguhan, salin `.env.example` menjadi `.env` dan isi dengan proyek Supabase **staging** yang telah dipasang. Jalankan:

```bash
python3 bin/dev.py
```

Script tersebut membaca `.env`, menetapkan `APP_ENV=local` dan `APP_URL=http://127.0.0.1:8000`, lalu menjalankan server lokal. Jangan membuka server pengembangan ke jaringan publik. PHP runtime tidak membaca `.env` secara otomatis di produksi; Vercel memasok environment.

## 6. Menjalankan pemeriksaan

```bash
php tests/security.php
php tests/routes.php
npm install
npm run test:db
npm run check:js
```

PGlite hanya dependensi pengujian. Tidak digunakan aplikasi produksi. Uji database membuat database PostgreSQL sementara di memori dengan tiruan minimal schema `auth`; tidak mengakses atau mengubah Supabase Anda.

Lihat `docs/HASIL_UJI.md` untuk hasil dan batas pengujian, `docs/KEAMANAN.md` untuk model keamanan, serta `docs/PANDUAN_PENGGUNA.md` untuk penggunaan sehari-hari.

## Sumber

- Identitas sekolah: https://referensi.data.kemendikdasmen.go.id/pendidikan/npsn/30304181 (diakses 25 Oktober 2026).
- Vercel runtimes: https://vercel.com/docs/functions/runtimes
- PHP community runtime: https://github.com/vercel-community/php/blob/master/README.md
- Supabase Data API: https://supabase.com/docs/guides/api
- Supabase RLS: https://supabase.com/docs/guides/database/postgres/row-level-security
- Supabase Admin create user: https://supabase.com/docs/reference/javascript/auth-admin-createuser

Tidak ada klaim bebas kesalahan atau jaminan keamanan absolut. Uji staging dan pemeriksaan deployment dengan konfigurasi sebenarnya merupakan bagian dari pemasangan, bukan hal yang telah selesai dilakukan pada paket ini.
