-- Jalankan setelah 001 dan 002. Kunci diisi melalui perintah dari bin/generate-keys.php.
begin;
create schema if not exists extensions;
create extension if not exists pgcrypto with schema extensions;
create table private.login_guard_config (id boolean primary key default true check(id), secret text not null check(secret ~ '^[a-f0-9]{64}$'));
create table private.login_limits (bucket text primary key, window_no bigint not null, attempts integer not null, last_seen timestamptz not null default now());
revoke all on private.login_guard_config,private.login_limits from public,anon,authenticated;
create function public.login_gate(p_bucket text,p_time bigint,p_signature text) returns jsonb
language plpgsql security definer set search_path='' as $$
declare k text; n integer; w bigint;
begin
 select secret into k from private.login_guard_config where id=true;
 if k is null or p_bucket is null or p_signature is null or p_time is null or p_bucket !~ '^[a-f0-9]{64}$' or p_signature !~ '^[a-f0-9]{64}$'
 or abs(extract(epoch from clock_timestamp())-p_time)>60 then raise exception 'Login guard tidak valid'; end if;
 if encode(extensions.hmac(p_bucket || ':' || p_time::text,k,'sha256'),'hex')<>p_signature then raise exception 'Login guard tidak valid'; end if;
 w:=floor(extract(epoch from now())/600);
 insert into private.login_limits(bucket,window_no,attempts) values(p_bucket,w,1)
 on conflict(bucket) do update set window_no=w,attempts=case when login_limits.window_no=w then login_limits.attempts+1 else 1 end,last_seen=now()
 returning attempts into n;
 return jsonb_build_object('allowed',n<=8);
end $$;
revoke all on function public.login_gate(text,bigint,text) from public;
grant execute on function public.login_gate(text,bigint,text) to anon,authenticated;
-- Pemeliharaan berkala dengan SQL Editor/Cron:
-- delete from private.login_limits where last_seen < now()-interval '2 days';
commit;
