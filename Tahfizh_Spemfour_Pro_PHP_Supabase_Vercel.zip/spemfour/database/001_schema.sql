-- Jalankan sekali pada proyek Supabase baru melalui SQL Editor.
begin;
create schema if not exists private;
revoke all on schema private from public;
grant usage on schema private to authenticated;

create table public.profiles (
 id uuid primary key references auth.users(id) on delete restrict,
 identifier text not null unique check(identifier ~ '^[0-9]{6,25}$'),
 name text not null check(length(name) between 2 and 100),
 role text not null check(role in ('admin','teacher','student')),
 active boolean not null default true, created_at timestamptz not null default now()
);
create table public.classes (
 id uuid primary key default gen_random_uuid(), name text not null check(length(name) between 1 and 40),
 academic_year text not null check(academic_year ~ '^[0-9]{4}/[0-9]{4}$'),
 created_at timestamptz not null default now(), unique(name,academic_year)
);
create table public.students (
 id uuid primary key default gen_random_uuid(), nisn text not null unique check(nisn ~ '^[0-9]{6,25}$'),
 name text not null check(length(name) between 2 and 100), class_id uuid not null references public.classes(id) on delete restrict,
 gender text not null check(gender in ('L','P')), profile_id uuid unique references public.profiles(id) on delete restrict,
 active boolean not null default true, created_at timestamptz not null default now()
);
create table public.assignments (
 id uuid primary key default gen_random_uuid(), teacher_id uuid not null references public.profiles(id) on delete restrict,
 class_id uuid not null references public.classes(id) on delete restrict, unique(teacher_id,class_id)
);
create table public.surahs (id smallint primary key check(id between 1 and 114), name text not null, verses smallint not null check(verses>0));
create table public.recitations (
 id uuid primary key default gen_random_uuid(), student_id uuid not null references public.students(id) on delete restrict,
 teacher_id uuid not null references public.profiles(id) on delete restrict,
 recorded_on date not null default current_date,
 surah_id smallint not null references public.surahs(id), verse_from smallint not null check(verse_from>=1),
 verse_to smallint not null check(verse_to>=verse_from), kind text not null check(kind in ('Hafalan baru','Murajaah')),
 score smallint not null check(score between 0 and 100), quality text not null check(quality in ('Lancar','Perlu pengulangan')),
 notes text not null default '' check(length(notes)<=1000), created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table public.targets (
 id uuid primary key default gen_random_uuid(), student_id uuid not null references public.students(id) on delete restrict,
 month date not null check(extract(day from month)=1), sessions_goal smallint not null check(sessions_goal between 1 and 100),
 description text not null default '' check(length(description)<=300), created_by uuid not null references public.profiles(id),
 created_at timestamptz not null default now(), updated_at timestamptz not null default now(), unique(student_id,month)
);
create table public.achievements (
 id uuid primary key default gen_random_uuid(), student_id uuid not null references public.students(id) on delete restrict,
 achieved_on date not null, title text not null check(length(title) between 3 and 150),
 description text not null default '' check(length(description)<=1000), created_by uuid not null references public.profiles(id),
 created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table public.attendance (
 id uuid primary key default gen_random_uuid(), student_id uuid not null references public.students(id) on delete restrict,
 attended_on date not null, status text not null check(status in ('Hadir','Izin','Sakit','Alpa')),
 notes text not null default '' check(length(notes)<=300), teacher_id uuid not null references public.profiles(id),
 created_at timestamptz not null default now(), updated_at timestamptz not null default now(), unique(student_id,attended_on)
);
create table public.app_sessions (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references public.profiles(id) on delete cascade,
 expires_at timestamptz not null check(expires_at<=now()+interval '31 minutes'), created_at timestamptz not null default now()
);
create table public.audit_logs (
 id uuid primary key default gen_random_uuid(), actor_id uuid, action text not null, entity text not null,
 entity_id uuid, created_at timestamptz not null default now()
);
create index on public.students(class_id);
create index on public.students(profile_id);
create index on public.assignments(teacher_id,class_id);
create index on public.recitations(student_id,recorded_on);
create index on public.recitations(teacher_id);
create index on public.targets(student_id,month);
create index on public.achievements(student_id);
create index on public.attendance(student_id,attended_on);
create index on public.app_sessions(user_id,expires_at);
create index on public.audit_logs(created_at desc);

create function private.role() returns text language sql stable security definer set search_path='' as $$
 select role from public.profiles where id=(select auth.uid()) and active
$$;
create function private.can_class(cid uuid) returns boolean language sql stable security definer set search_path='' as $$
 select coalesce(private.role()='admin' or
 (private.role()='teacher' and exists(select 1 from public.assignments a where a.class_id=cid and a.teacher_id=(select auth.uid()))) or
 (private.role()='student' and exists(select 1 from public.students s where s.class_id=cid and s.profile_id=(select auth.uid()))),false)
$$;
create function private.can_student(sid uuid) returns boolean language sql stable security definer set search_path='' as $$
 select coalesce(exists(select 1 from public.students s where s.id=sid and
 (private.role()='admin' or (private.role()='teacher' and private.can_class(s.class_id)) or
 (private.role()='student' and s.profile_id=(select auth.uid())))),false)
$$;
create function private.write_student(sid uuid) returns boolean language sql stable security definer set search_path='' as $$
 select coalesce(exists(select 1 from public.students s where s.id=sid and s.active and
 private.role() in ('admin','teacher') and private.can_class(s.class_id)),false)
$$;
revoke all on all functions in schema private from public;
grant execute on function private.role(),private.can_class(uuid),private.can_student(uuid),private.write_student(uuid) to authenticated;

alter table public.profiles enable row level security;
alter table public.classes enable row level security;
alter table public.students enable row level security;
alter table public.assignments enable row level security;
alter table public.surahs enable row level security;
alter table public.recitations enable row level security;
alter table public.targets enable row level security;
alter table public.achievements enable row level security;
alter table public.attendance enable row level security;
alter table public.app_sessions enable row level security;
alter table public.audit_logs enable row level security;

revoke all on table public.profiles,public.classes,public.students,public.assignments,public.surahs,public.recitations,public.targets,public.achievements,public.attendance,public.app_sessions,public.audit_logs from public,anon,authenticated;
grant select on public.profiles,public.surahs,public.audit_logs to authenticated;
grant update(active) on public.profiles to authenticated;
grant select,insert,update,delete on public.classes,public.assignments,public.recitations,public.targets,public.achievements,public.attendance to authenticated;
grant select,insert on public.students to authenticated;
grant update(nisn,name,class_id,gender,active) on public.students to authenticated;
grant select,insert,delete on public.app_sessions to authenticated;
grant all on table public.profiles,public.classes,public.students,public.assignments,public.surahs,public.recitations,public.targets,public.achievements,public.attendance,public.app_sessions,public.audit_logs to service_role;

create policy profile_read on public.profiles for select to authenticated using(id=(select auth.uid()) or private.role()='admin');
create policy profile_status on public.profiles for update to authenticated using(private.role()='admin' and id<>(select auth.uid())) with check(private.role()='admin' and id<>(select auth.uid()));
create policy classes_read on public.classes for select to authenticated using(private.can_class(id));
create policy classes_admin on public.classes for all to authenticated using(private.role()='admin') with check(private.role()='admin');
create policy students_read on public.students for select to authenticated using(private.can_student(id));
create policy students_insert on public.students for insert to authenticated with check(private.role()='admin' and profile_id is null);
create policy students_update on public.students for update to authenticated using(private.role()='admin') with check(private.role()='admin');
create policy assignments_read on public.assignments for select to authenticated using(private.role()='admin' or (private.role()='teacher' and teacher_id=(select auth.uid())));
create policy assignments_admin on public.assignments for all to authenticated using(private.role()='admin') with check(private.role()='admin');
create policy surahs_read on public.surahs for select to authenticated using(private.role() is not null);
create policy audit_admin on public.audit_logs for select to authenticated using(private.role()='admin');
create policy session_read on public.app_sessions for select to authenticated using(user_id=(select auth.uid()) and private.role() is not null);
create policy session_insert on public.app_sessions for insert to authenticated with check(user_id=(select auth.uid()) and private.role() is not null);
create policy session_delete on public.app_sessions for delete to authenticated using(user_id=(select auth.uid()));

do $$ declare t text; creator text; begin
 foreach t in array array['recitations','attendance','targets','achievements'] loop
   creator := case when t in ('recitations','attendance') then 'teacher_id' else 'created_by' end;
   execute format('create policy read_rows on public.%I for select to authenticated using(private.can_student(student_id))',t);
   execute format('create policy insert_rows on public.%I for insert to authenticated with check(private.write_student(student_id) and %I=(select auth.uid()))',t,creator);
   execute format('create policy update_rows on public.%I for update to authenticated using(private.write_student(student_id) and (private.role()=''admin'' or %I=(select auth.uid()))) with check(private.write_student(student_id) and (private.role()=''admin'' or %I=(select auth.uid())))',t,creator,creator);
   execute format('create policy delete_rows on public.%I for delete to authenticated using(private.role()=''admin'')',t);
 end loop;
end $$;

create function private.validate_row() returns trigger language plpgsql security definer set search_path='' as $$
declare v integer;
begin
 if TG_OP='UPDATE' then
   NEW.id:=OLD.id; NEW.created_at:=OLD.created_at; NEW.updated_at:=now();
   if TG_TABLE_NAME in ('recitations','attendance') then NEW.teacher_id:=OLD.teacher_id; else NEW.created_by:=OLD.created_by; end if;
 else NEW.created_at:=now(); NEW.updated_at:=now(); end if;
 if TG_TABLE_NAME='recitations' then
   select verses into v from public.surahs where id=NEW.surah_id;
   if v is null or NEW.verse_to>v then raise exception 'Rentang ayat tidak valid'; end if;
   if NEW.recorded_on>(now() at time zone 'Asia/Makassar')::date then raise exception 'Tanggal di masa depan tidak diizinkan'; end if;
 elsif TG_TABLE_NAME='attendance' and NEW.attended_on>(now() at time zone 'Asia/Makassar')::date then raise exception 'Tanggal di masa depan tidak diizinkan';
 elsif TG_TABLE_NAME='achievements' and NEW.achieved_on>(now() at time zone 'Asia/Makassar')::date then raise exception 'Tanggal di masa depan tidak diizinkan';
 end if;
 return NEW;
end $$;
create function private.audit_change() returns trigger language plpgsql security definer set search_path='' as $$
begin
 insert into public.audit_logs(actor_id,action,entity,entity_id) values(auth.uid(),TG_OP,TG_TABLE_NAME,case when TG_OP='DELETE' then OLD.id else NEW.id end);
 return case when TG_OP='DELETE' then OLD else NEW end;
end $$;
create function private.validate_assignment() returns trigger language plpgsql security definer set search_path='' as $$
begin
 if not exists(select 1 from public.profiles where id=NEW.teacher_id and role='teacher' and active) then raise exception 'Guru tidak valid'; end if;
 return NEW;
end $$;
create trigger check_assignment before insert or update on public.assignments for each row execute function private.validate_assignment();
create function private.validate_student_profile() returns trigger language plpgsql security definer set search_path='' as $$
begin
 if NEW.profile_id is not null and not exists(select 1 from public.profiles where id=NEW.profile_id and role='student' and identifier=NEW.nisn) then raise exception 'NISN dan akun siswa tidak sesuai'; end if;
 return NEW;
end $$;
create trigger check_student_profile before insert or update on public.students for each row execute function private.validate_student_profile();
do $$ declare t text; begin
 foreach t in array array['recitations','attendance','targets','achievements'] loop
 execute format('create trigger validate_record before insert or update on public.%I for each row execute function private.validate_row()',t);
 end loop;
 foreach t in array array['profiles','classes','students','assignments','recitations','attendance','targets','achievements'] loop
 execute format('create trigger audit_record after insert or update or delete on public.%I for each row execute function private.audit_change()',t);
 end loop;
end $$;
revoke all on function private.validate_row(),private.audit_change(),private.validate_assignment(),private.validate_student_profile() from public,anon,authenticated;

create function public.dashboard(p_month date) returns jsonb language sql stable security invoker set search_path='' as $$
 with r as (select * from public.recitations where recorded_on>=date_trunc('month',p_month)::date and recorded_on<(date_trunc('month',p_month)+interval '1 month')::date),
 progress as (select s.id,s.name,s.class_id,count(r.id) as sessions,round(avg(r.score),1) as average,
 (select sessions_goal from public.targets t where t.student_id=s.id and t.month=date_trunc('month',p_month)::date) as goal
 from public.students s left join r on r.student_id=s.id where s.active group by s.id)
 select jsonb_build_object(
 'students',(select count(*) from public.students where active),
 'sessions',(select count(*) from r),
 'average',(select round(avg(score),1) from r),
 'review',(select count(*) from r where quality='Perlu pengulangan'),
 'achievements',(select count(*) from public.achievements where achieved_on>=date_trunc('month',p_month)::date and achieved_on<(date_trunc('month',p_month)+interval '1 month')::date),
 'progress',coalesce((select jsonb_agg(x) from (select * from progress order by sessions desc,name limit 1000)x),'[]'::jsonb),
 'daily',coalesce((select jsonb_agg(x) from (select recorded_on as day,count(*) as total from r group by recorded_on order by recorded_on)x),'[]'::jsonb)
 )
$$;
revoke all on function public.dashboard(date) from public,anon;
grant execute on function public.dashboard(date) to authenticated;
-- Hapus sesi kedaluwarsa secara terjadwal dengan Supabase Cron bila tersedia:
-- delete from public.app_sessions where expires_at < now() - interval '1 day';
commit;
