<?php
declare(strict_types=1);
function securityHeaders(): void {
    header("Content-Security-Policy: default-src 'none'; script-src 'self'; style-src 'self'; img-src 'self' data:; font-src 'self'; connect-src 'self'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'; object-src 'none'");
    header('X-Content-Type-Options: nosniff'); header('X-Frame-Options: DENY');
    header('Referrer-Policy: no-referrer'); header('Permissions-Policy: camera=(), microphone=(), geolocation=()');
    header('Cache-Control: no-store, private');
    if (env('APP_ENV') !== 'local') header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
}
function seal(array $payload): string {
    $key = base64_decode(env('APP_KEY'), true);
    if ($key === false || strlen($key) !== 32) throw new HttpError(503, 'Konfigurasi aplikasi belum lengkap.');
    $nonce = random_bytes(SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);
    return base64_encode($nonce . sodium_crypto_secretbox(json_encode($payload, JSON_THROW_ON_ERROR), $nonce, $key));
}
function unseal(string $encoded): ?array {
    try {
        $key = base64_decode(env('APP_KEY'), true); $raw = base64_decode($encoded, true);
        if ($raw === false || strlen($raw) < 41 || !$key || strlen($key) !== 32) return null;
        $plain = sodium_crypto_secretbox_open(substr($raw, 24), substr($raw, 0, 24), $key);
        if ($plain === false) return null;
        $p = json_decode($plain, true, 16, JSON_THROW_ON_ERROR);
        return is_array($p) && ($p['exp'] ?? 0) > time() ? $p : null;
    } catch (Throwable) { return null; }
}
function cookieName(): string { return env('APP_ENV') === 'local' ? 'spemfour_session' : '__Host-spemfour_session'; }
function setSession(array $data): void {
    setcookie(cookieName(), seal($data), ['expires' => $data['exp'], 'path' => '/', 'secure' => env('APP_ENV') !== 'local', 'httponly' => true, 'samesite' => 'Strict']);
}
function clearSession(): void {
    setcookie(cookieName(), '', ['expires' => time() - 3600, 'path' => '/', 'secure' => env('APP_ENV') !== 'local', 'httponly' => true, 'samesite' => 'Strict']);
}
function sessionData(): ?array { return unseal($_COOKIE[cookieName()] ?? ''); }
function csrf(array $s): void {
    $origin = $_SERVER['HTTP_ORIGIN'] ?? '';
    if (!hash_equals(rtrim(env('APP_URL'), '/'), $origin)) throw new HttpError(403, 'Origin tidak diizinkan. Muat ulang halaman.');
    if (!hash_equals($s['csrf'] ?? '', $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '') || empty($s['csrf'])) throw new HttpError(403, 'Token keamanan tidak valid. Muat ulang halaman.');
}
function currentUser(array $session): array {
    if (empty($session['access']) || empty($session['sid'])) throw new HttpError(401, 'Silakan masuk kembali.');
    $token = $session['access'];
    $user = sb('GET', '/auth/v1/user', null, $token);
    $sessions = db('app_sessions', ['select'=>'id', 'id'=>'eq.'.uuid($session['sid']), 'expires_at'=>'gt.'.gmdate('c')], $token);
    if (!$sessions) { clearSession(); throw new HttpError(401, 'Sesi telah berakhir.'); }
    $profiles = db('profiles', ['select'=>'id,identifier,name,role,active', 'id'=>'eq.'.$user['id']], $token);
    if (!$profiles || !$profiles[0]['active']) throw new HttpError(403, 'Akun belum diaktifkan oleh pengelola.');
    return $profiles[0];
}
function staff(array $u): void { if (!in_array($u['role'], ['admin','teacher'], true)) throw new HttpError(403, 'Akses khusus guru.'); }
function admin(array $u): void { if ($u['role'] !== 'admin') throw new HttpError(403, 'Akses khusus administrator.'); }
