<?php
declare(strict_types=1);
function dispatch(): void {
    securityHeaders();
    $path=parse_url($_SERVER['REQUEST_URI']??'/',PHP_URL_PATH); $method=$_SERVER['REQUEST_METHOD']??'GET';
    if ($method==='GET' && in_array($path,['/','/login','/dashboard','/demo'],true)) {
        header('Content-Type: text/html; charset=utf-8'); readfile(dirname(__DIR__).'/public/index.html'); return;
    }
    $assets=['/assets/app.css'=>'text/css','/assets/app.js'=>'application/javascript','/assets/mark.svg'=>'image/svg+xml'];
    if ($method==='GET' && isset($assets[$path])) {
        header('Content-Type: '.$assets[$path].'; charset=utf-8'); readfile(dirname(__DIR__).'/public'.$path); return;
    }
    if ($path==='/api/health' && $method==='GET') respond(['configured'=>configured(),'service'=>'Tahfizh Spemfour Pro']);
    if (!str_starts_with((string)$path,'/api/')) throw new HttpError(404,'Halaman tidak ditemukan.');
    if (!configured()) throw new HttpError(503,'Aplikasi belum terhubung. Isi environment variable dan jalankan SQL sesuai README.');
    if ($path==='/api/session' && $method==='GET') {
        $s=sessionData();
        if(!$s) { $s=['csrf'=>bin2hex(random_bytes(32)),'exp'=>time()+1800]; setSession($s); }
        $u=null;
        if(!empty($s['access'])) {
            try {$u=currentUser($s);} catch(HttpError $e) {
                if(!in_array($e->status,[401,403],true))throw $e;
                $s=['csrf'=>bin2hex(random_bytes(32)),'exp'=>time()+1800];setSession($s);
            }
        }
        respond(['csrf'=>$s['csrf'],'user'=>$u,'expires_at'=>$s['exp']]);
    }
    $s=sessionData(); if(!$s) throw new HttpError(401,'Sesi berakhir. Muat ulang halaman.');
    if($method!=='GET') csrf($s);
    if($path==='/api/login' && $method==='POST') {
        $b=body(); $id=identifier($b['identifier']??null); $pw=$b['password']??null;
        if(!is_string($pw)||strlen($pw)<1||strlen($pw)>256)throw new HttpError(422,'Password tidak valid.');
        $bucket=hash_hmac('sha256',$id,env('LOGIN_GUARD_KEY'));$timestamp=time();
        $gate=sb('POST','/rest/v1/rpc/login_gate',['p_bucket'=>$bucket,'p_time'=>$timestamp,'p_signature'=>hash_hmac('sha256',$bucket.':'.$timestamp,env('LOGIN_GUARD_KEY'))]);
        if(empty($gate['allowed']))throw new HttpError(429,'Batas percobaan akun tercapai. Tunggu hingga 10 menit lalu coba kembali.');
        $domain=env('AUTH_EMAIL_DOMAIN','accounts.spemfour.invalid');
        if(!preg_match('/^[a-z0-9.-]+$/D',$domain)) throw new HttpError(503,'Konfigurasi login tidak valid.');
        $auth=sb('POST','/auth/v1/token?grant_type=password',['email'=>$id.'@'.$domain,'password'=>$pw]);
        $profiles=db('profiles',['select'=>'id,identifier,name,role,active','id'=>'eq.'.$auth['user']['id']],$auth['access_token']);
        if(!$profiles || !$profiles[0]['active']) throw new HttpError(403,'Akun belum diaktifkan oleh pengelola.');
        $exp=min(time()+1800,(int)($auth['expires_at']??time()+1800));
        $sessions=db('app_sessions',[],$auth['access_token'],'POST',['user_id'=>$auth['user']['id'],'expires_at'=>gmdate('c',$exp)]);
        $fresh=['access'=>$auth['access_token'],'sid'=>$sessions[0]['id'],'csrf'=>bin2hex(random_bytes(32)),'exp'=>$exp];
        setSession($fresh); respond(['user'=>$profiles[0],'csrf'=>$fresh['csrf'],'expires_at'=>$exp]);
    }
    $u=currentUser($s); $token=$s['access'];
    if($path==='/api/logout' && $method==='POST') {
        db('app_sessions',['id'=>'eq.'.$s['sid']],$token,'DELETE'); clearSession(); respond(['ok'=>true]);
    }
    if($path==='/api/lookups' && $method==='GET') {
        respond(['classes'=>allRows('classes',['select'=>'*','order'=>'name.asc,id.asc'],$token),
          'students'=>allRows('students',['select'=>'id,nisn,name,class_id,gender,active','order'=>'name.asc,id.asc'],$token),
          'surahs'=>db('surahs',['select'=>'*','order'=>'id.asc'],$token),
          'teachers'=>$u['role']==='admin'?db('profiles',['select'=>'id,name,identifier','role'=>'eq.teacher','active'=>'eq.true','order'=>'name.asc'],$token):[]]);
    }
    if($path==='/api/dashboard' && $method==='GET') {
        $month=($_GET['month']??date('Y-m')).'-01'; dateValue($month);
        respond(sb('POST','/rest/v1/rpc/dashboard',['p_month'=>$month],$token));
    }
    if($path==='/api/report' && $method==='GET') {
        $from=dateValue($_GET['from']??date('Y-m-01')); $to=dateValue($_GET['to']??date('Y-m-d'));
        if($from>$to || (strtotime($to)-strtotime($from))>366*86400) throw new HttpError(422,'Rentang laporan maksimal 366 hari.');
        $q=['select'=>'id,recorded_on,student_id,surah_id,verse_from,verse_to,kind,score,quality,notes','and'=>'(recorded_on.gte.'.$from.',recorded_on.lte.'.$to.')','order'=>'recorded_on.asc,id.asc'];
        if(!empty($_GET['student_id'])) $q['student_id']='eq.'.uuid($_GET['student_id']);
        $rows=allRows('recitations',$q,$token);
        $students=allRows('students',['select'=>'id,nisn,name,class_id','order'=>'id.asc'],$token);
        $map=array_column($students,null,'id'); $classes=array_column(db('classes',['select'=>'id,name'],$token),'name','id');
        $surahs=array_column(db('surahs',['select'=>'id,name'],$token),'name','id');
        foreach($rows as &$r){$st=$map[$r['student_id']]??[]; $r['student_name']=$st['name']??'';$r['nisn']=$st['nisn']??'';$r['class_name']=$classes[$st['class_id']??'']??'';$r['surah_name']=$surahs[$r['surah_id']]??'';} unset($r);
        if(($_GET['format']??'')==='csv') {
            header('Content-Type: text/csv; charset=utf-8');header('Content-Disposition: attachment; filename="laporan-hafalan-'.$from.'.csv"');
            $fp=fopen('php://output','w');fwrite($fp,"\xEF\xBB\xBF");
            fputcsv($fp,['Tanggal','NISN','Nama','Kelas','Surah','Dari ayat','Sampai ayat','Jenis','Nilai','Hasil','Catatan'],',','"','');
            foreach($rows as $r)fputcsv($fp,array_map('csvSafe',[$r['recorded_on'],$r['nisn'],$r['student_name'],$r['class_name'],$r['surah_name'],$r['verse_from'],$r['verse_to'],$r['kind'],$r['score'],$r['quality'],$r['notes']]),',','"','');
            fclose($fp); return;
        }
        respond(['rows'=>$rows,'from'=>$from,'to'=>$to]);
    }
    if(!preg_match('~^/api/(classes|students|assignments|recitations|targets|achievements|attendance|profiles|audit_logs)(?:/([a-f0-9-]+))?$~D',(string)$path,$match)) throw new HttpError(404,'Endpoint tidak ditemukan.');
    $resource=$match[1]; $id=isset($match[2])?uuid($match[2]):null;
    if(in_array($resource,['profiles','assignments','audit_logs'],true)) admin($u);
    if($method==='GET') {
        $q=['select'=>'*','limit'=>51,'offset'=>number($_GET['offset']??0,0,100000),'order'=>in_array($resource,['profiles','classes','students'],true)?'name.asc,id.asc':($resource==='assignments'?'id.asc':'created_at.desc,id.desc')];
        if($id)$q['id']='eq.'.$id;
        if(!empty($_GET['student_id']) && in_array($resource,['recitations','targets','achievements','attendance'],true))$q['student_id']='eq.'.uuid($_GET['student_id']);
        if(!empty($_GET['class_id']) && $resource==='students')$q['class_id']='eq.'.uuid($_GET['class_id']);
        if(!empty($_GET['search']) && in_array($resource,['students','profiles'],true)) {
            $search=textValue($_GET['search'],1,60); $search=preg_replace('/[%_*(),.\\\\]/u',' ',$search); $q['name']='ilike.*'.$search.'*';
        }
        $rows=db($resource,$q,$token);$hasMore=count($rows)>50;
        respond(['rows'=>array_slice($rows,0,50),'has_more'=>$hasMore]);
    }
    staff($u);
    if(in_array($resource,['classes','students','assignments','profiles'],true))admin($u);
    if($resource==='audit_logs')throw new HttpError(405,'Log audit hanya dapat dibaca.');
    if($method==='DELETE') {
        admin($u); if(!$id)throw new HttpError(422,'ID wajib diisi.');
        if(!in_array($resource,['classes','assignments','recitations','targets','achievements','attendance'],true))throw new HttpError(405,'Gunakan nonaktifkan untuk menjaga riwayat.');
        $result=db($resource,['id'=>'eq.'.$id],$token,'DELETE');if(!$result)throw new HttpError(404,'Data tidak ditemukan atau tidak diizinkan.'); respond(['ok'=>true]);
    }
    if(!in_array($method,['POST','PATCH'],true))throw new HttpError(405,'Metode tidak didukung.');
    $b=body();
    if($resource==='profiles') {
        if($method!=='PATCH'||!$id||$id===$u['id']||!is_bool($b['active']??null))throw new HttpError(422,'Hanya status akun lain yang dapat diubah.');
        $d=['active'=>$b['active']];
    } elseif($resource==='students' && $method==='PATCH' && array_keys($b)===['active']) {
        if(!is_bool($b['active']))throw new HttpError(422,'Status tidak valid.');$d=['active'=>$b['active']];
    } else {
        $d=cleanData($resource,$b,$u);
        if($method==='PATCH' && in_array($resource,['recitations','attendance','targets','achievements'],true)) { unset($d['teacher_id'],$d['created_by']); }
        if($method==='PATCH' && $resource==='students') unset($d['active']);
    }
    if($method==='PATCH' && !$id)throw new HttpError(422,'ID wajib diisi.');
    if($method==='POST' && $id)throw new HttpError(405,'URL tidak valid.');
    $rows=db($resource,$id?['id'=>'eq.'.$id]:[],$token,$method,$d);
    if(!$rows)throw new HttpError(404,'Data tidak ditemukan atau tidak diizinkan.');
    respond(['row'=>$rows[0]],$method==='POST'?201:200);
}
