<?php
declare(strict_types=1);
function textValue(mixed $value, int $min=1, int $max=200): string {
    if (!is_string($value)) throw new HttpError(422,'Isian teks tidak valid.');
    $value=trim($value);
    if (mb_strlen($value)<$min || mb_strlen($value)>$max || preg_match('/[\x00-\x08\x0B\x0C\x0E-\x1F]/',$value)) throw new HttpError(422,'Panjang atau karakter isian tidak valid.');
    return $value;
}
function uuid(mixed $v): string {
    if(!is_string($v)||!preg_match('/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/Di',$v)) throw new HttpError(422,'ID data tidak valid.');
    return $v;
}
function number(mixed $v,int $min,int $max): int {
    if(filter_var($v,FILTER_VALIDATE_INT)===false || $v<$min || $v>$max) throw new HttpError(422,'Angka di luar rentang.'); return (int)$v;
}
function dateValue(mixed $v): string {
    if (!is_string($v)) throw new HttpError(422,'Tanggal tidak valid.');
    $d=DateTimeImmutable::createFromFormat('!Y-m-d',$v);
    if(!$d||$d->format('Y-m-d')!==$v) throw new HttpError(422,'Tanggal tidak valid.'); return $v;
}
function choice(mixed $v,array $allowed): string { if(!is_string($v)||!in_array($v,$allowed,true))throw new HttpError(422,'Pilihan tidak valid.'); return $v; }
function identifier(mixed $v): string { if(!is_string($v)||!preg_match('/^[0-9]{6,25}$/D',$v))throw new HttpError(422,'NIP/NISN harus terdiri dari 6–25 digit.'); return $v; }
function cleanData(string $resource,array $b,array $u): array {
    return match($resource) {
        'classes'=>['name'=>textValue($b['name']??null,1,40),'academic_year'=>textValue($b['academic_year']??null,9,9)],
        'students'=>['nisn'=>identifier($b['nisn']??null),'name'=>textValue($b['name']??null,2,100),'class_id'=>uuid($b['class_id']??null),'gender'=>choice($b['gender']??null,['L','P']),'active'=>true],
        'assignments'=>['teacher_id'=>uuid($b['teacher_id']??null),'class_id'=>uuid($b['class_id']??null)],
        'recitations'=>['student_id'=>uuid($b['student_id']??null),'recorded_on'=>dateValue($b['recorded_on']??null),'surah_id'=>number($b['surah_id']??null,1,114),'verse_from'=>number($b['verse_from']??null,1,286),'verse_to'=>number($b['verse_to']??null,1,286),'kind'=>choice($b['kind']??null,['Hafalan baru','Murajaah']),'score'=>number($b['score']??null,0,100),'quality'=>choice($b['quality']??null,['Lancar','Perlu pengulangan']),'notes'=>textValue($b['notes']??'',0,1000),'teacher_id'=>$u['id']],
        'targets'=>['student_id'=>uuid($b['student_id']??null),'month'=>dateValue(($b['month']??'').'-01'),'sessions_goal'=>number($b['sessions_goal']??null,1,100),'description'=>textValue($b['description']??'',0,300),'created_by'=>$u['id']],
        'achievements'=>['student_id'=>uuid($b['student_id']??null),'achieved_on'=>dateValue($b['achieved_on']??null),'title'=>textValue($b['title']??null,3,150),'description'=>textValue($b['description']??'',0,1000),'created_by'=>$u['id']],
        'attendance'=>['student_id'=>uuid($b['student_id']??null),'attended_on'=>dateValue($b['attended_on']??null),'status'=>choice($b['status']??null,['Hadir','Izin','Sakit','Alpa']),'notes'=>textValue($b['notes']??'',0,300),'teacher_id'=>$u['id']],
        default=>throw new HttpError(404,'Menu tidak ditemukan.')
    };
}
function csvSafe(mixed $v): string { $s=(string)($v??''); return preg_match('/^[\s]*[=+@\-\t\r\n]/u',$s) ? "'".$s : $s; }
