<?php
declare(strict_types=1);
date_default_timezone_set('Asia/Makassar');
ini_set('display_errors', '0');
require __DIR__ . '/security.php';
require __DIR__ . '/supabase.php';
require __DIR__ . '/validation.php';
require __DIR__ . '/routes.php';

function env(string $name, string $default = ''): string { return (string)(getenv($name) ?: $default); }
function configured(): bool {
    return preg_match('~^https://[a-z0-9-]+\.supabase\.co$~D', env('SUPABASE_URL')) === 1
        && strlen(env('SUPABASE_ANON_KEY')) > 20 && strlen(base64_decode(env('APP_KEY'), true) ?: '') === 32
        && preg_match('/^[a-f0-9]{64}$/D', env('LOGIN_GUARD_KEY')) === 1
        && (bool)filter_var(env('APP_URL'), FILTER_VALIDATE_URL);
}
final class HttpError extends RuntimeException {
    public function __construct(public int $status, string $message) { parent::__construct($message); }
}
function respond(mixed $data, int $status = 200): never {
    http_response_code($status); header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR); exit;
}
function body(): array {
    if (!str_starts_with(strtolower($_SERVER['CONTENT_TYPE'] ?? ''), 'application/json')) throw new HttpError(415, 'Gunakan JSON.');
    $raw = file_get_contents('php://input', false, null, 0, 32769);
    if (strlen($raw) > 32768) throw new HttpError(413, 'Permintaan terlalu besar.');
    try { $v = json_decode($raw, true, 32, JSON_THROW_ON_ERROR); } catch (JsonException) { throw new HttpError(400, 'JSON tidak valid.'); }
    if (!is_array($v) || array_is_list($v)) throw new HttpError(400, 'Objek JSON diperlukan.');
    return $v;
}
