<?php
declare(strict_types=1);
function sb(string $method, string $path, ?array $data = null, ?string $token = null, array $extra = []): array {
    $base = env('SUPABASE_URL');
    if (!preg_match('~^https://[a-z0-9-]+\.supabase\.co$~D', $base)) throw new HttpError(503, 'Supabase belum dikonfigurasi.');
    $ch = curl_init($base . $path);
    $headers = ['apikey: '.env('SUPABASE_ANON_KEY'), 'Content-Type: application/json', 'Accept: application/json'];
    if ($token) $headers[] = 'Authorization: Bearer '.$token;
    curl_setopt_array($ch, [CURLOPT_CUSTOMREQUEST=>$method, CURLOPT_RETURNTRANSFER=>true, CURLOPT_CONNECTTIMEOUT=>5, CURLOPT_TIMEOUT=>15,
        CURLOPT_FOLLOWLOCATION=>false, CURLOPT_PROTOCOLS=>CURLPROTO_HTTPS, CURLOPT_SSL_VERIFYPEER=>true,
        CURLOPT_HTTPHEADER=>array_merge($headers,$extra)]);
    if ($data !== null) curl_setopt($ch,CURLOPT_POSTFIELDS,json_encode($data,JSON_THROW_ON_ERROR));
    $raw = curl_exec($ch); $status = curl_getinfo($ch,CURLINFO_RESPONSE_CODE); curl_close($ch);
    if ($raw === false || !$status) throw new HttpError(503, 'Layanan data belum dapat dihubungi. Coba kembali.');
    if ($status >= 400) {
        if ($status === 429) throw new HttpError(429, 'Terlalu banyak percobaan. Tunggu beberapa menit.');
        if (str_starts_with($path, '/auth/v1/token')) throw new HttpError(401, 'ID atau password tidak sesuai, atau akun belum aktif.');
        if ($status === 401) throw new HttpError(401, 'Sesi berakhir. Silakan masuk kembali.');
        if ($status === 409) throw new HttpError(409, 'Data sudah ada atau masih digunakan.');
        throw new HttpError($status === 403 ? 403 : 422, 'Data ditolak. Periksa isian, hak akses, dan konfigurasi database.');
    }
    return $raw === '' ? [] : (json_decode($raw,true,64,JSON_THROW_ON_ERROR) ?? []);
}
function db(string $table, array $query, string $token, string $method = 'GET', ?array $data = null): array {
    return sb($method, '/rest/v1/'.$table.'?'.http_build_query($query,'','&',PHP_QUERY_RFC3986),$data,$token,['Prefer: return=representation']);
}
function allRows(string $table, array $query, string $token): array {
    $out=[];
    for ($offset=0;$offset<20000;$offset+=1000) {
        $rows=db($table,array_merge($query,['limit'=>1000,'offset'=>$offset]),$token);
        $out=array_merge($out,$rows); if(count($rows)<1000) return $out;
    }
    throw new HttpError(422,'Hasil terlalu besar. Persempit rentang tanggal laporan.');
}
