<?php
declare(strict_types=1);
require dirname(__DIR__) . '/app/bootstrap.php';
try {
    dispatch();
} catch (HttpError $e) {
    respond(['error' => $e->getMessage()], $e->status);
} catch (Throwable $e) {
    $ref = bin2hex(random_bytes(6));
    error_log('spemfour error ' . $ref . ' type=' . get_class($e));
    respond(['error' => 'Permintaan gagal diproses. Hubungi pengelola dengan kode ' . $ref], 500);
}
