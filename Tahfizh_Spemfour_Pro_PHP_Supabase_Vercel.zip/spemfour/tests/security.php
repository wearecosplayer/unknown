<?php
declare(strict_types=1);
require dirname(__DIR__).'/app/bootstrap.php';
$passed=0;
function ok(bool $condition,string $label): void { global $passed;if(!$condition)throw new RuntimeException('FAIL: '.$label);$passed++;echo "PASS: $label\n"; }
function reject(callable $f,string $label): void {try{$f();}catch(HttpError){ok(true,$label);return;}ok(false,$label);}
putenv('APP_KEY='.base64_encode(random_bytes(32)));putenv('APP_URL=https://school.example');
$valid=['exp'=>time()+30,'csrf'=>'test-token','access'=>'test-access'];
$sealed=seal($valid);ok(unseal($sealed)===$valid,'Cookie round-trip');
$bytes=base64_decode($sealed);$bytes[30]=chr(ord($bytes[30])^1);ok(unseal(base64_encode($bytes))===null,'Cookie tampering rejected');
ok(unseal(seal(['exp'=>time()-1]))===null,'Expired cookie rejected');
ok(unseal('malformed!')===null,'Malformed cookie rejected');
$_SERVER['HTTP_ORIGIN']='https://evil.example';$_SERVER['HTTP_X_CSRF_TOKEN']='test-token';reject(fn()=>csrf($valid),'Cross-origin request rejected');
$_SERVER['HTTP_ORIGIN']='https://school.example';$_SERVER['HTTP_X_CSRF_TOKEN']='wrong';reject(fn()=>csrf($valid),'Wrong CSRF rejected');
$_SERVER['HTTP_X_CSRF_TOKEN']='test-token';csrf($valid);ok(true,'Valid CSRF accepted');
reject(fn()=>uuid('1 OR 1=1'),'UUID injection rejected');
reject(fn()=>identifier('123456@example.com'),'Identifier format enforced');
ok(identifier('0000000123')==='0000000123','Identifier leading zeros preserved');
reject(fn()=>number('101',0,100),'Score upper bound');
reject(fn()=>number('-1',0,100),'Score lower bound');
reject(fn()=>dateValue('2026-02-30'),'Impossible date rejected');
reject(fn()=>dateValue('2026-1-1'),'Noncanonical date rejected');
ok(dateValue('2024-02-29')==='2024-02-29','Leap day accepted');
reject(fn()=>staff(['role'=>'student']),'Student writes rejected');
reject(fn()=>admin(['role'=>'teacher']),'Teacher admin access rejected');
ok(csvSafe('=HYPERLINK("bad")')[0]==="'",'CSV formula neutralized');
ok(csvSafe(' +cmd')[0]==="'",'CSV leading whitespace neutralized');
ok(csvSafe('Catatan biasa')==='Catatan biasa','CSV text preserved');
echo "$passed tests passed.\n";
