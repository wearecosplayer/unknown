<?php
declare(strict_types=1);
// Tests actual PHP entry point in isolated child processes without a real backend.
$entry=dirname(__DIR__).'/api/index.php';$passed=0;
foreach([
 ['/',200,'Tahfizh Spemfour Pro'],['/demo',200,'MODE DEMO'],
 ['/assets/app.js',200,'use strict'],['/api/health',200,'"configured":false'],
 ['/.env',404,'Halaman tidak ditemukan'],['/app/security.php',404,'Halaman tidak ditemukan'],
 ['/database/001_schema.sql',404,'Halaman tidak ditemukan'],['/api/students',503,'belum terhubung'],
] as [$path,$status,$content]) {
 $code='putenv("SUPABASE_URL=");$_SERVER["REQUEST_URI"]='.var_export($path,true).';$_SERVER["REQUEST_METHOD"]="GET";http_response_code(200);register_shutdown_function(function(){echo "\\nSTATUS=".http_response_code();});require '.var_export($entry,true).';';
 $command=[PHP_BINARY,'-n','-r',$code];
 $proc=proc_open($command,[0=>['pipe','r'],1=>['pipe','w'],2=>['pipe','w']],$pipes);
 fclose($pipes[0]);$out=stream_get_contents($pipes[1]);$err=stream_get_contents($pipes[2]);fclose($pipes[1]);fclose($pipes[2]);$exit=proc_close($proc);
 if($exit!==0||!str_contains($out,'STATUS='.$status)||!str_contains($out,$content))throw new RuntimeException('FAIL '.$path.' '.$err.' '.$out);
 $passed++;echo 'PASS '.$path.' '.$status."\n";
}
echo "$passed route checks passed.\n";
