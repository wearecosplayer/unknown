# Hasil pengujian — 26 Oktober 2026

## Hasil otomatis

| Pemeriksaan | Hasil |
| --- | --- |
| Sintaks seluruh file PHP | Lolos pada PHP 8.3.6 |
| Sintaks JavaScript | Lolos `node --check` |
| Keamanan PHP | 20 pemeriksaan lolos |
| Routing dan penutupan path source | 8 pemeriksaan lolos |
| Migrasi/otorisasi PostgreSQL | 39 pemeriksaan lolos melalui PGlite 0.5.11 |

Total **67 pemeriksaan otomatis** selain pemeriksaan sintaks. Output disertakan dalam `php-test-results.txt` dan `database-test-results.txt`.

Uji PHP mencakup autentikasi/enkripsi cookie, cookie rusak/kedaluwarsa, origin dan CSRF tidak valid, validasi identifier/tanggal/nilai, pembatas peran, serta formula CSV. Uji routing menjalankan entrypoint PHP dalam proses terisolasi; ini bukan pengujian jaringan produksi.

Uji database mengeksekusi ketiga migration pada PostgreSQL WASM dengan ekstensi pgcrypto. Pengujian mencakup 114 surah, guru hanya kelas binaan, penulisan atas nama guru lain ditolak, perubahan pemilik catatan dicegah, siswa hanya membaca data pribadi, eskalasi peran ditolak, akun nonaktif kehilangan akses, relasi NISN/akun konsisten, session dibatasi/dicabut, audit tidak dapat dipalsukan, serta signature dan batas percobaan login.

## Uji browser pada mode demo

- Halaman dashboard dan login berhasil dirender oleh PHP.
- Form tambah setoran dapat diisi dan disimpan; jumlah setoran berubah 42 → 43.
- Nilai setoran dapat diedit 92 → 95 dan tampil kembali pada tabel.
- Filter siswa menyisakan catatan siswa terpilih.
- Laporan menampilkan 43 baris setelah penambahan; tombol ekspor dan cetak aktif.
- Menu kelas, kehadiran, target, prestasi, akun, serta kelas binaan dapat dibuka.
- Screenshot dashboard dan login ada di `screenshots/`. Seluruh identitas/angka demo fiktif. Screenshot login memperlihatkan keadaan belum dikonfigurasi.

Satu masalah demo (`crypto.randomUUID` pada origin HTTP) ditemukan dan diperbaiki menggunakan `crypto.getRandomValues`. Form diuji ulang dan berhasil.

## Batas verifikasi

1. Belum ada proyek Supabase milik pengguna yang terhubung. Supabase Auth, PostgREST, provisioning akun, dan transaksi end-to-end pada layanan nyata **belum diuji**. PGlite menguji SQL/otorisasi dengan schema auth minimal yang disimulasikan; bukan pengganti seluruh platform Supabase.
2. Deployment/build melalui Vercel `vercel-php@0.9.0` belum dijalankan pada akun pengguna. Kompatibilitas runtime, kapasitas, timeout, dan konfigurasi domain/environment harus diuji pada staging.
3. Uji browser dilakukan pada viewport desktop. CSS responsif tersedia, tetapi uji perangkat seluler fisik dan lintas-browser belum dilakukan.
4. Tersedianya tombol ekspor/cetak telah diperiksa; hasil cetak PDF aktual dan unduhan CSV end-to-end pada akun produksi belum diuji. Fungsi netralisasi formula CSV diuji di PHP.
5. Halaman internal aplikasi acuan belum dapat diakses karena hambatan formulir login. Kemiripan dashboard/menu internal belum diverifikasi.
6. Pengujian beban, pemulihan backup, pentest independen, dan audit keamanan menyeluruh belum dilakukan. Kelulusan uji bukan jaminan bebas semua kesalahan.

## Pemeriksaan setelah deploy

Gunakan data uji untuk mengulangi login admin/guru/siswa, kelas binaan, simpan/edit setoran, laporan CSV/PDF, logout, penonaktifan akun, dan percobaan login ke-9. Pastikan `/api/health` menunjukkan `configured: true`, tetapi jangan menganggap hasil health sebagai bukti koneksi/database sudah benar. Pastikan request ke `/.env`, `/app/security.php`, dan `/database/001_schema.sql` ditolak. Baru kemudian masukkan data sekolah asli.
