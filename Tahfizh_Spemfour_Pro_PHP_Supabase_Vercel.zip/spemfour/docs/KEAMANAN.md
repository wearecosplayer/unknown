# Model keamanan dan operasional

## Perlindungan yang diimplementasikan

1. Password diverifikasi Supabase Auth; aplikasi tidak menyimpan hash/password pengguna sendiri. Tidak ada kredensial default.
2. Token akses disimpan dalam cookie terenkripsi dan diautentikasi menggunakan Sodium secretbox dengan nonce acak. Cookie produksi berprefiks `__Host-`, `Secure`, `HttpOnly`, `SameSite=Strict`, tanpa Domain.
3. Masa sesi maksimal 30 menit, tanpa refresh token otomatis. Setiap request data memverifikasi pengguna melalui Supabase Auth, status profil, dan session ID di database. Logout menghapus session ID sehingga cookie lama ditolak oleh aplikasi.
4. Request perubahan memerlukan origin sama persis dan token CSRF acak yang terikat cookie. Tidak ada CORS wildcard.
5. Login dibatasi delapan percobaan per akun per jendela tetap 10 menit di database. Bucket berupa HMAC ID; RPC dibatasi signature HMAC server dan timestamp. Pergantian jendela dapat mengizinkan burst di batas waktu. Tidak ada reset counter saat login berhasil.
6. RLS diterapkan pada seluruh tabel publik. Guru hanya membaca siswa kelas binaannya dan menulis catatan atas namanya; guru mengedit catatannya sendiri. Admin dapat mengelola lintas kelas. Siswa hanya membaca datanya sendiri. Profil nonaktif tidak dapat membaca/menulis data pembelajaran.
7. Kolom role tidak bisa diubah oleh role `authenticated`; pembuatan/perubahan role harus melalui jalur operator. Kunci `service_role` hanya digunakan alat CLI lokal. Jangan menaruhnya di environment aplikasi web.
8. Skema menggunakan UUID, foreign keys, batas nilai, batas tanggal, rentang ayat per surah, dan indeks. REST filter dibentuk dari isian yang divalidasi; tidak ada SQL string dari input pengguna.
9. Antarmuka melakukan escaping konten; tidak menggunakan HTML dari catatan pengguna. CSP membatasi script, style, dan koneksi ke origin sendiri. Header keamanan, no-store, dan error generik mengurangi paparan data.
10. Ekspor CSV menetralkan awalan formula. Setiap ekspor melewati autentikasi/RLS. Batas laporan maksimal 366 hari dan kurang dari 20.000 baris; permintaan terlalu besar ditolak, tidak dipotong diam-diam.
11. Trigger audit mencatat tindakan, tabel, ID data, ID pelaku, serta waktu. Log tidak dapat dibuat/diubah oleh akun biasa. Log tidak memuat isi lengkap catatan siswa.

## Pengaturan operasional yang tetap diperlukan

- Aktifkan MFA untuk akun pemilik Supabase/Vercel/Git. **MFA pengguna akhir belum diimplementasikan pada aplikasi ini.**
- Nonaktifkan public signup Supabase, terapkan password kuat, dan batasi percobaan pada Supabase serta firewall Vercel untuk pertahanan per-IP dan trafik massal. Pembatas aplikasi per-akun tidak menggantikan mitigasi DDoS. Percobaan login yang diarahkan ke ID tertentu dapat membuat akun menunggu sisa jendela 10 menit.
- RLS tetap wajib meskipun semua permintaan normal melewati PHP. Jika JWT berhasil dicuri di luar cookie, JWT masih mengikuti masa hidup Supabase; pencabutan session aplikasi saja bukan pencabutan JWT pada seluruh layanan Supabase. Nonaktifkan profil untuk menutup akses tabel segera.
- Rotasi `APP_KEY` membatalkan cookie lama. Rotasi `LOGIN_GUARD_KEY` harus diselaraskan antara environment dan `private.login_guard_config`. Cabut/rotasi service-role key bila bocor.
- Hapus session kedaluwarsa dan bucket login lama melalui Supabase Cron atau tugas operator. Contoh SQL berada pada migration.
- Siapkan backup, retensi, dan uji pemulihan sesuai kebutuhan sekolah. Uji restore sebelum mengandalkan backup. Penghapusan catatan melalui aplikasi tidak memiliki undo; audit menyimpan metadata, bukan salinan pemulihan.
- Pengubahan kelas siswa mengalihkan akses riwayatnya ke guru kelas yang baru; pastikan sesuai tata kelola sekolah. Akun siswa terhubung tetap dapat membaca riwayatnya saat status data siswa tidak aktif; nonaktifkan **profil akun** bila akses login harus dicabut.
- Tinjau hak akses saat pergantian guru, semester, atau kelulusan. Hindari mencatat informasi sensitif yang tidak relevan dengan monitoring hafalan.
- Sistem tidak mengirim email/WhatsApp, tidak merekam audio, tidak menyediakan reset password mandiri, dan tidak mengimpor data aplikasi lama secara otomatis. Pemulihan akun dilakukan operator melalui jalur administrasi.
- Dokumen ini menjelaskan kontrol teknis, bukan sertifikasi keamanan atau pernyataan kepatuhan hukum. Pengujian penetrasi independen belum dilakukan.

## Pemeriksaan penerimaan sebelum data asli digunakan

Gunakan proyek staging dan data fiktif untuk menguji admin, dua guru dari kelas berbeda, serta dua siswa. Pastikan akses lintas kelas ditolak; edit guru lain ditolak; user nonaktif gagal; percobaan kesembilan dibatasi; logout membatalkan cookie; ekspor sesuai akses; asset/database/source path tidak terbuka; formulir menolak tanggal/ayat/nilai tidak valid. Uji kembali setelah perubahan runtime, SQL, atau kebijakan Supabase.
