# Panduan penggunaan

## Administrator

Masuk dengan ID yang dibuat operator. Isi kelas/tahun ajaran, kemudian siswa. Buat akun guru melalui wizard lokal yang dijelaskan pada README dan tetapkan kelas binaan. Akun guru yang belum mendapat kelas akan melihat data kosong; ini merupakan pembatasan akses yang disengaja.

Data Siswa menyediakan pencarian nama dan filter kelas. Tombol nonaktifkan menjaga riwayat siswa. Untuk menghentikan akses login seseorang, buka Akun Pengguna dan nonaktifkan akunnya. Identitas akun dan role dikelola operator; UI tidak mengubahnya.

Log Aktivitas memperlihatkan tindakan perubahan data serta ID pelakunya. Halaman ini tidak merekam seluruh pembacaan data atau perubahan password pada Supabase. Gunakan log penyedia untuk aktivitas autentikasi.

## Guru pembimbing

1. Buka Setoran Hafalan → Tambah data.
2. Pilih siswa, tanggal, surah, hafalan baru/murajaah, rentang ayat, nilai 0–100, dan hasil penilaian.
3. Isi catatan seperlunya, lalu simpan. Batas ayat mengikuti surah; tanggal mendatang ditolak.
4. Catatan buatan sendiri dapat diedit. Koreksi catatan guru lain atau penghapusan harus melalui admin.
5. Atur Target Hafalan per siswa dan bulan, berdasarkan jumlah setoran. Satu siswa hanya memiliki satu target pada bulan yang sama. Edit catatan target yang ada untuk revisi.
6. Kehadiran hanya satu catatan per siswa per tanggal; edit catatan yang ada bila perlu koreksi.
7. Prestasi Siswa menampung prestasi yang telah diverifikasi guru; aplikasi tidak menentukan kelulusan atau prestasi secara otomatis.

## Siswa

Login dengan NISN dan password pribadi yang dibuat operator. Siswa melihat dashboard, setoran, kehadiran, target, prestasi, serta laporan miliknya. Tombol pengubahan data tidak tersedia. Sampaikan kesalahan pencatatan kepada guru.

## Laporan

Pilih tanggal awal/akhir dan, jika perlu, siswa. Klik Tampilkan. Data kemudian bisa diunduh sebagai CSV atau dicetak. Untuk PDF pilih Cetak / PDF lalu Save as PDF di dialog browser. Gunakan format landscape A4. Jika mengubah filter, tekan Tampilkan lagi sebelum mengekspor.

Jumlah setoran mencakup hafalan baru dan murajaah; catatan pengulangan tetap dihitung sebagai sesi. Rata-rata nilai menggunakan catatan pada bulan terpilih, sedangkan tabel “Setoran terbaru” mencakup seluruh periode.

CSV diperlakukan sebagai dokumen terbatas karena memuat identitas dan catatan pembelajaran. Hindari membagikannya di luar pihak yang berwenang.

## Demo dan sesi

`/demo` berisi data fiktif tanpa password. Perubahan demo hilang saat halaman dimuat ulang dan tidak dikirim ke Supabase. Mode demo bukan akses administrator produksi.

Sesi produksi berakhir maksimal 30 menit setelah login. Simpan pekerjaan sebelum masa sesi habis. Jika sesi berakhir, muat ulang halaman dan masuk kembali. Keluar akun setelah selesai pada perangkat bersama.
